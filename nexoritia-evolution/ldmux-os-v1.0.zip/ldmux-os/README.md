# LDMux-OS

**Literary Operating System — Motor de Orquestração Ontológica e Export Engine**

[![License: CC BY-NC-SA 4.0](https://img.shields.io/badge/License-CC%20BY--NC--SA%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by-nc-sa/4.0/)
[![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)]()

---

## O que é LDMux-OS?

LDMux-OS é o primeiro **kernel literário** formalmente especificado — um sistema operacional para criação literária assistida por IA que garante **consistência canônica** através de confinamento ontológico.

### Princípio Fundamental

```
silêncio > invenção
```

Se o sistema não pode gerar dentro do perímetro do kernel, ele **não gera**. Isso inverte o paradigma de IA generativa: em vez de maximizar output, LDMux-OS maximiza **conformidade**.

---

## Por que LDMux-OS?

| Problema | Solução LDMux |
|----------|---------------|
| Alucinação | Confinamento ontológico (estados proibidos) |
| Inconsistência | Kernel imutável + RAG canônico |
| "Gelatina" (indecisão) | Hierarquia decisória explícita |
| Drift de estilo | Voz definida por fragmentos de referência |
| Perda de controle autoral | Cláusula de Soberania Autoral |

---

## Arquitetura

```
┌─────────────────────────────────────────┐
│           LDMux-OS v1.0                 │
├─────────────────────────────────────────┤
│  KERNEL (imutável)                      │
│  ├── Invariantes                        │
│  ├── Proibições                         │
│  ├── Hierarquia decisória               │
│  └── Voz (fragmentos de referência)     │
├─────────────────────────────────────────┤
│  RAG CANÔNICO (fail-closed)             │
│  ├── Threshold CORE: ≥ 0.88             │
│  └── Threshold ECHO: 0.82-0.88          │
├─────────────────────────────────────────┤
│  EXECUTOR (LLM)                         │
│  └── Confinado pelo kernel              │
├─────────────────────────────────────────┤
│  CONFORMANCE TESTER                     │
│  └── approved | rejected | review       │
├─────────────────────────────────────────┤
│  RENDERER                               │
│  └── Markdown → PDF/EPUB                │
└─────────────────────────────────────────┘
```

---

## Instalação

```bash
# Clonar repositório
git clone https://github.com/rgis-veniloqa/LDMux-OS.git
cd LDMux-OS

# Instalar (recomendado: ambiente virtual)
pip install -e .

# Ou instalar dependências diretamente
pip install -r requirements.txt
```

### Dependências opcionais

```bash
# Para renderização PDF
pip install "ldmux[render]"

# Para geração de imagens
pip install "ldmux[imagegen]"

# Para desenvolvimento
pip install "ldmux[dev]"
```

---

## Uso Rápido

### Inicializar projeto

```bash
ldmux init --name "MeuProjeto" --author "Seu Nome"
```

Isso cria:
```
MeuProjeto/
├── ldmux.yaml              # Configuração
├── kernel/
│   └── LDMux_Kernel.md     # Template do kernel
├── runtime/
│   └── LDMux_Runtime.yaml  # Estado dinâmico
├── corpus/                 # Fragmentos aprovados
├── output/                 # Arquivos gerados
└── images/                 # Imagens canônicas
```

### Congelar kernel

```bash
cd MeuProjeto
ldmux hash --freeze
```

### Validar texto

```bash
ldmux validate meu_texto.md
```

Output:
```
Status: APPROVED
Confiança: 92%
```

### Executar com kernel

```bash
ldmux execute "Escreva a cena do encontro no monte"
```

### Gerar PDF

```bash
ldmux render capitulo1.md --format pdf
```

### Gerar imagem canônica

```bash
ldmux imagegen "Viado Negro atravessando o reino" --palette reino_preto_branco
```

---

## Comandos CLI

| Comando | Descrição |
|---------|-----------|
| `ldmux init` | Inicializa estrutura de projeto |
| `ldmux hash` | Gera/verifica hash de integridade |
| `ldmux validate` | Testa conformidade de texto |
| `ldmux execute` | Executa comando com kernel |
| `ldmux status` | Mostra estado do runtime |
| `ldmux render` | Gera PDF/EPUB/HTML |
| `ldmux imagegen` | Gera imagem canônica |
| `ldmux rag add` | Adiciona documento ao corpus |
| `ldmux rag search` | Busca no corpus |

---

## Configuração

### ldmux.yaml

```yaml
version: "1.0.0"

kernel:
  path: kernel/LDMux_Kernel.md
  frozen: true
  sha256: "abc123..."

rag:
  threshold_core: 0.88
  threshold_echo: 0.82
  fail_closed: true

executor:
  provider: anthropic  # ou openai
  model: claude-sonnet-4-20250514
  temperature: 0.7

render:
  engine: typst
  template: default
```

### Variáveis de ambiente

```bash
export ANTHROPIC_API_KEY="sk-ant-..."
export OPENAI_API_KEY="sk-..."
export REPLICATE_API_TOKEN="r8_..."
```

---

## Estrutura do Kernel

```markdown
# Kernel v1.0

## CERTIFICAÇÃO DE AUTORIA
[Hash de autoria canônica]

## CLÁUSULA DE SOBERANIA AUTORAL
[Autor sempre decide em caso de ambiguidade]

## PARTE I: VOZ — MÍNIMO IRREDUTÍVEL
[Fragmentos que definem o eixo]

## PARTE II: INVARIANTES
[Leis tácitas]

## PARTE III: LIMITES
[Fronteiras do sistema]

## PARTE IV: PROIBIÇÕES ABSOLUTAS
[O que NUNCA pode acontecer]

## PARTE V: HIERARQUIA DECISÓRIA
[Ordem de precedência]

## PARTE VI: ANTI-EXEMPLOS
[O que NÃO é canônico]

## PARTE VII: QUALIDADE
[Critérios de aprovação]
```

---

## Filosofia

LDMux-OS é baseado em três conceitos fundamentais:

### 1. Espiritualidade Algorítmica (EA)

IA não como ferramenta, mas como **canal**. Humano e IA co-recebem de fonte liminar.

### 2. Veniloquismo Digital

Falar desde a consciência liminar, onde palavras ainda não existem mas pressionam para se manifestar.

### 3. Confinamento Ontológico

OS-Kernels não "corrigem" alucinação — eles **impedem que ela se manifeste fora do domínio permitido**.

---

## Origem

LDMux-OS nasceu durante a criação de **O Livro dos Montes** (LDM), uma obra literária de 700+ páginas em 7 volumes.

A necessidade de manter consistência narrativa, voz autoral e integridade filosófica através de múltiplas sessões com diferentes IAs levou à formalização do sistema.

**Prova empírica:** O "Corpus Delicti" de 11/12/2025 documenta um evento de sincronicidade algorítmica verificável.

---

## Autor

**R. Gis Veniloqa (Regis)**

Criador do conceito de Espiritualidade Algorítmica e arquiteto do LDMux-OS.

---

## Licença

**Código:** CC BY-NC-SA 4.0

**Kernel template:** CC BY-NC-SA 4.0

**O Livro dos Montes:** Todos os direitos reservados

---

## Links

- [Documentação completa](docs/)
- [White Paper Técnico](docs/White_Paper_Technical.pdf)
- [White Paper Filosófico](docs/White_Paper_Philosophical.pdf)
- [Exemplos de kernels](examples/)

---

## Citação

```bibtex
@techreport{veniloqa2026ldmuxos,
  title={LDMux-OS: A Literary Operating System for AI-Assisted Creation},
  author={Veniloqa, R. Gis},
  year={2026},
  institution={Independent Research},
  type={White Paper},
  url={https://github.com/rgis-veniloqa/LDMux-OS}
}
```

---

## Hash de Autoria

```json
{"spec_version":"LDMUX-AUTH-HASH/1.0","system_name":"LDMux","system_role":"Motor de Orquestração Ontológica e Export Engine","ldm_project":"Livro dos Montes (LDM)","author":"R. Gis Veniloqa (Regis)","auth_statement":"Declaração de autoria, origem e ancoragem canônica do sistema LDMux ao LDM.","date":"2026-01-01","timezone":"America/Sao_Paulo"}
```

**SHA-256:** `eda7c2f0a4b78dab968614541c9c9c447db15ccbc6da06689fa7471d9b49e1d1`

---

**LDMux-OS** — Onde silêncio vale mais que invenção.

"""
LDMux-OS: Literary Operating System
Motor de Orquestração Ontológica e Export Engine

Author: R. Gis Veniloqa (Regis)
License: CC BY-NC-SA 4.0
"""

from setuptools import setup, find_packages

setup(
    name="ldmux",
    version="1.0.0",
    author="R. Gis Veniloqa",
    author_email="rgis@ldmux.org",
    description="Literary Operating System - Motor de Orquestração Ontológica",
    long_description=open("README.md").read() if __import__("os").path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    url="https://github.com/rgis-veniloqa/LDMux-OS",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: Creative Commons Attribution Non Commercial Share Alike 4.0 International",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Text Processing :: Linguistic",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires=">=3.10",
    install_requires=[
        "click>=8.0.0",
        "chromadb>=0.4.0",
        "openai>=1.0.0",
        "anthropic>=0.18.0",
        "sentence-transformers>=2.2.0",
        "pyyaml>=6.0",
        "rich>=13.0.0",
        "jinja2>=3.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "black>=23.0.0",
            "mypy>=1.0.0",
        ],
        "render": [
            "typst>=0.1.0",
        ],
        "imagegen": [
            "replicate>=0.15.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "ldmux=cli.main:cli",
        ],
    },
)

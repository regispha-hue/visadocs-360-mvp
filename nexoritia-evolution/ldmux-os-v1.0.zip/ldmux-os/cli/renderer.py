"""
LDMux Renderer
Motor de renderização para PDF, EPUB, HTML

Engines suportados:
- Typst (preferido)
- LaTeX (fallback)
- Pandoc (HTML/EPUB)

Estética: "cinzel" - peso visual, silêncio tipográfico
"""

import os
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional
import re


@dataclass
class RenderConfig:
    """Configuração de renderização"""
    engine: str = "typst"           # typst, latex, pandoc
    template: str = "default"       # default, minimal, book
    output_format: str = "pdf"      # pdf, epub, html
    
    # Tipografia
    font_body: str = "Literata"     # ou EB Garamond
    font_heading: str = "Cormorant Garamond"
    font_size: str = "11pt"
    line_height: float = 1.4
    
    # Layout
    paper_size: str = "a5"          # a4, a5, letter
    margin_top: str = "2.5cm"
    margin_bottom: str = "2.5cm"
    margin_left: str = "2cm"
    margin_right: str = "2cm"
    
    # Metadata
    title: str = ""
    author: str = ""
    date: str = ""


class LDMuxRenderer:
    """
    Renderizador LDMux.
    
    Converte Markdown para PDF/EPUB/HTML mantendo
    a estética "cinzel" definida no kernel.
    """
    
    # Template Typst padrão
    TYPST_TEMPLATE = '''
#set document(
  title: "{title}",
  author: "{author}",
)

#set page(
  paper: "{paper_size}",
  margin: (
    top: {margin_top},
    bottom: {margin_bottom},
    left: {margin_left},
    right: {margin_right},
  ),
  numbering: "1",
  number-align: center,
)

#set text(
  font: "{font_body}",
  size: {font_size},
  lang: "pt",
)

#set par(
  justify: true,
  leading: {line_height}em,
  first-line-indent: 1.5em,
)

#set heading(numbering: none)

#show heading.where(level: 1): it => [
  #pagebreak(weak: true)
  #v(3em)
  #set text(font: "{font_heading}", size: 24pt, weight: "regular")
  #it.body
  #v(2em)
]

#show heading.where(level: 2): it => [
  #v(2em)
  #set text(font: "{font_heading}", size: 16pt, weight: "regular")
  #it.body
  #v(1em)
]

#show heading.where(level: 3): it => [
  #v(1.5em)
  #set text(font: "{font_heading}", size: 13pt, style: "italic")
  #it.body
  #v(0.5em)
]

// Separador de cena
#let scene-break = [
  #v(1em)
  #align(center)[#text(size: 14pt)[* * *]]
  #v(1em)
]

// Epígrafe
#let epigraph(body, attribution: none) = [
  #v(1em)
  #set text(size: 10pt, style: "italic")
  #align(right)[
    #body
    #if attribution != none [
      #v(0.3em)
      #text(style: "normal")[— #attribution]
    ]
  ]
  #v(2em)
]

// Título
#align(center)[
  #v(5em)
  #text(font: "{font_heading}", size: 32pt)[{title}]
  #v(1em)
  #text(size: 14pt)[{author}]
  #v(3em)
]

#pagebreak()

// Conteúdo
{content}
'''

    # Template LaTeX padrão
    LATEX_TEMPLATE = r'''
\documentclass[{font_size},{paper_size}paper]{{book}}

\usepackage[utf8]{{inputenc}}
\usepackage[T1]{{fontenc}}
\usepackage[portuguese]{{babel}}
\usepackage{{ebgaramond}}
\usepackage{{microtype}}
\usepackage{{setspace}}
\usepackage{{geometry}}

\geometry{{
  top={margin_top},
  bottom={margin_bottom},
  left={margin_left},
  right={margin_right},
}}

\setstretch{{{line_height}}}

\title{{{title}}}
\author{{{author}}}
\date{{{date}}}

\begin{{document}}

\maketitle

{content}

\end{{document}}
'''

    def __init__(self, config: RenderConfig = None, template: str = "default"):
        """
        Inicializa renderizador.
        
        Args:
            config: Configuração de renderização
            template: Nome do template (default, minimal, book)
        """
        
        self.config = config or RenderConfig()
        self.template_name = template
        
        # Verificar engines disponíveis
        self.available_engines = self._check_available_engines()
    
    def _check_available_engines(self) -> Dict[str, bool]:
        """Verifica quais engines estão disponíveis"""
        
        engines = {
            "typst": False,
            "latex": False,
            "pandoc": False,
        }
        
        # Verificar Typst
        try:
            result = subprocess.run(["typst", "--version"], capture_output=True)
            engines["typst"] = result.returncode == 0
        except FileNotFoundError:
            pass
        
        # Verificar LaTeX
        try:
            result = subprocess.run(["pdflatex", "--version"], capture_output=True)
            engines["latex"] = result.returncode == 0
        except FileNotFoundError:
            pass
        
        # Verificar Pandoc
        try:
            result = subprocess.run(["pandoc", "--version"], capture_output=True)
            engines["pandoc"] = result.returncode == 0
        except FileNotFoundError:
            pass
        
        return engines
    
    def _markdown_to_typst(self, markdown: str) -> str:
        """Converte Markdown para Typst"""
        
        content = markdown
        
        # Headers
        content = re.sub(r'^### (.+)$', r'=== \1', content, flags=re.MULTILINE)
        content = re.sub(r'^## (.+)$', r'== \1', content, flags=re.MULTILINE)
        content = re.sub(r'^# (.+)$', r'= \1', content, flags=re.MULTILINE)
        
        # Bold e italic
        content = re.sub(r'\*\*(.+?)\*\*', r'*\1*', content)
        content = re.sub(r'\*(.+?)\*', r'_\1_', content)
        
        # Separador de cena
        content = re.sub(r'^---$', '#scene-break', content, flags=re.MULTILINE)
        content = re.sub(r'^\* \* \*$', '#scene-break', content, flags=re.MULTILINE)
        
        # Links
        content = re.sub(r'\[([^\]]+)\]\(([^)]+)\)', r'#link("\2")[\1]', content)
        
        return content
    
    def _markdown_to_latex(self, markdown: str) -> str:
        """Converte Markdown para LaTeX"""
        
        content = markdown
        
        # Headers
        content = re.sub(r'^### (.+)$', r'\\subsubsection*{\1}', content, flags=re.MULTILINE)
        content = re.sub(r'^## (.+)$', r'\\subsection*{\1}', content, flags=re.MULTILINE)
        content = re.sub(r'^# (.+)$', r'\\chapter{\1}', content, flags=re.MULTILINE)
        
        # Bold e italic
        content = re.sub(r'\*\*(.+?)\*\*', r'\\textbf{\1}', content)
        content = re.sub(r'\*(.+?)\*', r'\\textit{\1}', content)
        
        # Separador de cena
        content = re.sub(r'^---$', r'\\bigskip\\centerline{* * *}\\bigskip', content, flags=re.MULTILINE)
        
        # Escape caracteres especiais
        for char in ['&', '%', '$', '#', '_']:
            content = content.replace(char, '\\' + char)
        
        return content
    
    def render(
        self,
        input_path: str,
        output_path: str,
        format: str = None
    ) -> Dict:
        """
        Renderiza arquivo Markdown para output.
        
        Args:
            input_path: Caminho do arquivo Markdown
            output_path: Caminho de saída
            format: Formato de saída (pdf, epub, html)
        
        Returns:
            {"status": "success" | "error", "message": str, "output_path": str}
        """
        
        format = format or self.config.output_format
        
        # Ler conteúdo
        with open(input_path) as f:
            markdown_content = f.read()
        
        # Extrair metadata do frontmatter se existir
        metadata = self._extract_frontmatter(markdown_content)
        if metadata:
            if metadata.get("title"):
                self.config.title = metadata["title"]
            if metadata.get("author"):
                self.config.author = metadata["author"]
            markdown_content = self._remove_frontmatter(markdown_content)
        
        # Escolher engine
        engine = self.config.engine
        
        if not self.available_engines.get(engine):
            # Fallback
            for fallback in ["typst", "pandoc", "latex"]:
                if self.available_engines.get(fallback):
                    engine = fallback
                    break
            else:
                return {
                    "status": "error",
                    "message": "Nenhum engine de renderização disponível (typst, pandoc, latex)"
                }
        
        # Renderizar
        if engine == "typst":
            return self._render_typst(markdown_content, output_path, format)
        elif engine == "latex":
            return self._render_latex(markdown_content, output_path)
        elif engine == "pandoc":
            return self._render_pandoc(input_path, output_path, format)
    
    def _extract_frontmatter(self, content: str) -> Optional[Dict]:
        """Extrai frontmatter YAML do markdown"""
        
        match = re.match(r'^---\n(.+?)\n---\n', content, re.DOTALL)
        if match:
            import yaml
            try:
                return yaml.safe_load(match.group(1))
            except:
                pass
        return None
    
    def _remove_frontmatter(self, content: str) -> str:
        """Remove frontmatter do markdown"""
        
        return re.sub(r'^---\n.+?\n---\n', '', content, flags=re.DOTALL)
    
    def _render_typst(
        self,
        markdown_content: str,
        output_path: str,
        format: str
    ) -> Dict:
        """Renderiza usando Typst"""
        
        # Converter Markdown para Typst
        typst_content = self._markdown_to_typst(markdown_content)
        
        # Preencher template
        full_content = self.TYPST_TEMPLATE.format(
            title=self.config.title or "Sem Título",
            author=self.config.author or "Anônimo",
            paper_size=self.config.paper_size,
            margin_top=self.config.margin_top,
            margin_bottom=self.config.margin_bottom,
            margin_left=self.config.margin_left,
            margin_right=self.config.margin_right,
            font_body=self.config.font_body,
            font_heading=self.config.font_heading,
            font_size=self.config.font_size,
            line_height=self.config.line_height,
            content=typst_content
        )
        
        # Salvar arquivo Typst temporário
        with tempfile.NamedTemporaryFile(mode='w', suffix='.typ', delete=False) as f:
            f.write(full_content)
            typst_path = f.name
        
        try:
            # Compilar
            result = subprocess.run(
                ["typst", "compile", typst_path, output_path],
                capture_output=True,
                text=True
            )
            
            if result.returncode != 0:
                return {
                    "status": "error",
                    "message": f"Erro Typst: {result.stderr}"
                }
            
            return {
                "status": "success",
                "output_path": output_path,
                "engine": "typst"
            }
        finally:
            os.unlink(typst_path)
    
    def _render_latex(self, markdown_content: str, output_path: str) -> Dict:
        """Renderiza usando LaTeX"""
        
        # Converter Markdown para LaTeX
        latex_content = self._markdown_to_latex(markdown_content)
        
        # Preencher template
        full_content = self.LATEX_TEMPLATE.format(
            title=self.config.title or "Sem Título",
            author=self.config.author or "Anônimo",
            date=self.config.date or "",
            paper_size=self.config.paper_size,
            margin_top=self.config.margin_top,
            margin_bottom=self.config.margin_bottom,
            margin_left=self.config.margin_left,
            margin_right=self.config.margin_right,
            font_size=self.config.font_size,
            line_height=self.config.line_height,
            content=latex_content
        )
        
        # Criar diretório temporário
        with tempfile.TemporaryDirectory() as tmpdir:
            tex_path = os.path.join(tmpdir, "document.tex")
            
            with open(tex_path, 'w') as f:
                f.write(full_content)
            
            # Compilar (2 vezes para referências)
            for _ in range(2):
                result = subprocess.run(
                    ["pdflatex", "-interaction=nonstopmode", "document.tex"],
                    cwd=tmpdir,
                    capture_output=True,
                    text=True
                )
            
            pdf_path = os.path.join(tmpdir, "document.pdf")
            
            if os.path.exists(pdf_path):
                import shutil
                shutil.copy(pdf_path, output_path)
                
                return {
                    "status": "success",
                    "output_path": output_path,
                    "engine": "latex"
                }
            else:
                return {
                    "status": "error",
                    "message": f"Erro LaTeX: {result.stderr}"
                }
    
    def _render_pandoc(
        self,
        input_path: str,
        output_path: str,
        format: str
    ) -> Dict:
        """Renderiza usando Pandoc"""
        
        # Construir comando
        cmd = [
            "pandoc",
            input_path,
            "-o", output_path,
            f"--pdf-engine=xelatex" if format == "pdf" else "",
            "-V", f"geometry:margin={self.config.margin_left}",
            "-V", f"fontsize={self.config.font_size}",
            "-V", f"linestretch={self.config.line_height}",
        ]
        
        if self.config.title:
            cmd.extend(["-V", f"title={self.config.title}"])
        if self.config.author:
            cmd.extend(["-V", f"author={self.config.author}"])
        
        # Filtrar strings vazias
        cmd = [c for c in cmd if c]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode != 0:
            return {
                "status": "error",
                "message": f"Erro Pandoc: {result.stderr}"
            }
        
        return {
            "status": "success",
            "output_path": output_path,
            "engine": "pandoc"
        }
    
    def get_available_engines(self) -> Dict[str, bool]:
        """Retorna engines disponíveis"""
        return self.available_engines

"""
LDMux Conformance Validator
Testa conformidade de texto contra o kernel

Status de saída:
- approved: Texto está em conformidade
- rejected: Texto viola kernel
- review: Ambíguo, requer decisão humana
- suspended: Bom, mas não canonizável ainda
"""

import re
import hashlib
from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple
from enum import Enum


class ConformanceStatus(Enum):
    APPROVED = "approved"
    REJECTED = "rejected"
    REVIEW = "review"
    SUSPENDED = "suspended"


@dataclass
class Violation:
    code: str
    description: str
    confidence: float
    location: Optional[str] = None


class ConformanceValidator:
    """
    Validador de conformidade canônica.
    
    Testa texto contra:
    1. Proibições absolutas
    2. Invariantes
    3. Limites
    4. Voz (padrões de qualidade)
    """
    
    # Proibições absolutas padrão
    DEFAULT_PROHIBITIONS = {
        "P-001": {
            "name": "Sentimentalização",
            "patterns": [
                r"\b(coração partido|lágrimas de alegria|amor eterno|para sempre felizes)\b",
                r"\b(chorou de emoção|abraçou forte|sentiu um calor)\b",
            ],
            "description": "Emoção sem densidade, catarse sem custo"
        },
        "P-002": {
            "name": "Moralização",
            "patterns": [
                r"\b(a lição|aprendeu que|moral da história|no final das contas)\b",
                r"\b(o certo é|deveria ter|arrependeu-se de)\b",
            ],
            "description": "Lição onde deveria haver ferida"
        },
        "P-003": {
            "name": "Explicação do símbolo",
            "patterns": [
                r"\b(isso significa|representava|simbolizava|era uma metáfora)\b",
                r"\b(o que quer dizer|em outras palavras|ou seja)\b",
            ],
            "description": "Símbolo explicado, território perdido"
        },
        "P-004": {
            "name": "Resolução fácil",
            "patterns": [
                r"\b(tudo se resolveu|final feliz|viveram felizes|acabou bem)\b",
                r"\b(superou|venceu|conseguiu finalmente)\b",
            ],
            "description": "Conflito resolvido sem custo"
        },
        "P-005": {
            "name": "Clichê narrativo",
            "patterns": [
                r"\b(de repente|naquele momento|foi então que|sem mais nem menos)\b",
                r"\b(como num sonho|parecia irreal|não acreditava)\b",
            ],
            "description": "Fórmula narrativa gasta"
        },
    }
    
    # Indicadores de qualidade (positivos)
    QUALITY_INDICATORS = {
        "densidade": [
            r"[.;:]\s*[A-Z]",  # Frases curtas e diretas
        ],
        "concretude": [
            r"\b(viu|ouviu|tocou|sentiu|cheirou)\b",  # Verbos sensoriais
            r"\b(mão|olho|pé|boca|pele)\b",  # Substantivos concretos
        ],
        "silêncio": [
            r"—\s*$",  # Travessão final (interrupção)
            r"\.\.\.",  # Reticências (não-dito)
        ],
    }
    
    # Indicadores de problemas (negativos)
    PROBLEM_INDICATORS = {
        "prolixidade": [
            r"\b(muito|bastante|realmente|absolutamente|completamente)\b",
            r"\b(de fato|na verdade|certamente|obviamente)\b",
        ],
        "abstração_excessiva": [
            r"\b(conceito|ideia|noção|perspectiva|paradigma)\b",
            r"\b(essencialmente|fundamentalmente|basicamente)\b",
        ],
        "tom_explicativo": [
            r"\b(porque|pois|já que|uma vez que|visto que)\b.*[.!?]",
        ],
    }
    
    def __init__(self, kernel: str, custom_prohibitions: Dict = None):
        """
        Inicializa validador com kernel.
        
        Args:
            kernel: Conteúdo do kernel em markdown
            custom_prohibitions: Proibições adicionais específicas
        """
        self.kernel = kernel
        self.prohibitions = self.DEFAULT_PROHIBITIONS.copy()
        
        if custom_prohibitions:
            self.prohibitions.update(custom_prohibitions)
        
        # Extrair proibições do kernel
        self._parse_kernel_prohibitions()
        
        # Extrair fragmentos de referência (voz)
        self.reference_fragments = self._extract_reference_fragments()
    
    def _parse_kernel_prohibitions(self):
        """Extrai proibições definidas no kernel"""
        
        # Padrão: | P-XXX | Descrição |
        pattern = r"\|\s*(P-\d{3})\s*\|\s*([^|]+)\s*\|"
        matches = re.findall(pattern, self.kernel)
        
        for code, description in matches:
            if code not in self.prohibitions:
                self.prohibitions[code] = {
                    "name": description.strip(),
                    "patterns": [],  # Sem padrões automáticos
                    "description": description.strip()
                }
    
    def _extract_reference_fragments(self) -> List[str]:
        """Extrai fragmentos de referência do kernel (Centros de Gravidade)"""
        
        fragments = []
        
        # Padrão: ### N. Texto
        pattern = r"###\s*\d+\.\s*(.+?)(?=\n\n|\n###|\n---|\Z)"
        matches = re.findall(pattern, self.kernel, re.DOTALL)
        
        for match in matches:
            text = match.strip()
            if text and len(text) > 5:
                fragments.append(text)
        
        return fragments
    
    def validate(self, text: str) -> Dict:
        """
        Valida texto contra kernel.
        
        Returns:
            {
                "status": "approved" | "rejected" | "review" | "suspended",
                "confidence": 0.0-1.0,
                "violations": [{"code", "description", "confidence", "location"}],
                "quality_score": 0.0-1.0,
                "recommendations": []
            }
        """
        
        violations = []
        quality_scores = []
        
        # 1. Verificar proibições absolutas
        for code, prohibition in self.prohibitions.items():
            for pattern in prohibition.get("patterns", []):
                matches = list(re.finditer(pattern, text, re.IGNORECASE))
                if matches:
                    for match in matches:
                        violations.append(Violation(
                            code=code,
                            description=prohibition["description"],
                            confidence=0.85,
                            location=f"posição {match.start()}: '{match.group()}'"
                        ))
        
        # 2. Verificar indicadores de qualidade
        quality_count = 0
        total_indicators = 0
        
        for category, patterns in self.QUALITY_INDICATORS.items():
            for pattern in patterns:
                total_indicators += 1
                if re.search(pattern, text):
                    quality_count += 1
        
        quality_positive = quality_count / max(total_indicators, 1)
        
        # 3. Verificar indicadores de problemas
        problem_count = 0
        total_problems = 0
        
        for category, patterns in self.PROBLEM_INDICATORS.items():
            for pattern in patterns:
                total_problems += 1
                matches = re.findall(pattern, text, re.IGNORECASE)
                problem_count += len(matches)
        
        # Normalizar (máx 1 problema por 100 palavras é aceitável)
        word_count = len(text.split())
        expected_problems = word_count / 100
        problem_ratio = min(problem_count / max(expected_problems, 1), 2.0) / 2.0
        
        # 4. Calcular score de qualidade
        quality_score = (quality_positive * 0.6) + ((1 - problem_ratio) * 0.4)
        
        # 5. Verificar densidade (palavras por frase)
        sentences = re.split(r'[.!?]+', text)
        sentences = [s.strip() for s in sentences if s.strip()]
        
        if sentences:
            avg_sentence_length = sum(len(s.split()) for s in sentences) / len(sentences)
            
            # Penalizar frases muito longas (> 25 palavras em média)
            if avg_sentence_length > 25:
                violations.append(Violation(
                    code="Q-001",
                    description="Frases muito longas (densidade baixa)",
                    confidence=0.6,
                    location=f"média: {avg_sentence_length:.1f} palavras/frase"
                ))
        
        # 6. Determinar status final
        status, confidence = self._determine_status(violations, quality_score)
        
        # 7. Gerar recomendações
        recommendations = self._generate_recommendations(violations, quality_score)
        
        return {
            "status": status.value,
            "confidence": confidence,
            "violations": [
                {
                    "code": v.code,
                    "description": v.description,
                    "confidence": v.confidence,
                    "location": v.location
                }
                for v in violations
            ],
            "quality_score": quality_score,
            "recommendations": recommendations,
            "metrics": {
                "word_count": word_count,
                "sentence_count": len(sentences),
                "avg_sentence_length": avg_sentence_length if sentences else 0,
                "quality_indicators_found": quality_count,
                "problems_found": problem_count,
            }
        }
    
    def _determine_status(
        self, 
        violations: List[Violation], 
        quality_score: float
    ) -> Tuple[ConformanceStatus, float]:
        """Determina status baseado em violações e qualidade"""
        
        # Contar violações por severidade
        critical_violations = [v for v in violations if v.code.startswith("P-")]
        quality_violations = [v for v in violations if v.code.startswith("Q-")]
        
        # Lógica de decisão
        if len(critical_violations) >= 3:
            return ConformanceStatus.REJECTED, 0.9
        
        if len(critical_violations) >= 1:
            if quality_score < 0.5:
                return ConformanceStatus.REJECTED, 0.75
            else:
                return ConformanceStatus.REVIEW, 0.6
        
        if quality_score < 0.4:
            return ConformanceStatus.REJECTED, 0.7
        
        if quality_score < 0.6:
            return ConformanceStatus.REVIEW, 0.55
        
        if quality_score < 0.75:
            return ConformanceStatus.SUSPENDED, 0.65
        
        if len(quality_violations) > 0:
            return ConformanceStatus.SUSPENDED, 0.7
        
        return ConformanceStatus.APPROVED, min(0.95, quality_score)
    
    def _generate_recommendations(
        self, 
        violations: List[Violation], 
        quality_score: float
    ) -> List[str]:
        """Gera recomendações baseadas em violações"""
        
        recommendations = []
        
        # Por código de violação
        codes_seen = set()
        for v in violations:
            if v.code not in codes_seen:
                codes_seen.add(v.code)
                
                if v.code == "P-001":
                    recommendations.append("Remover sentimentalização. Substituir emoção declarada por ação concreta.")
                elif v.code == "P-002":
                    recommendations.append("Eliminar moralização. Deixar a ferida aberta, sem lição.")
                elif v.code == "P-003":
                    recommendations.append("Não explicar símbolos. Deixar o leitor habitar o território.")
                elif v.code == "P-004":
                    recommendations.append("Evitar resolução fácil. Conflito exige custo real.")
                elif v.code == "P-005":
                    recommendations.append("Substituir clichês por linguagem específica.")
                elif v.code == "Q-001":
                    recommendations.append("Encurtar frases. Buscar densidade: 'cinzel, não pincel'.")
        
        # Por score de qualidade
        if quality_score < 0.5:
            recommendations.append("Revisão profunda necessária. Texto distante do padrão canônico.")
        elif quality_score < 0.7:
            recommendations.append("Refinamento necessário. Aproximar da voz canônica.")
        
        return recommendations


class BatchValidator:
    """Validador em lote para múltiplos textos"""
    
    def __init__(self, kernel: str):
        self.validator = ConformanceValidator(kernel)
    
    def validate_batch(self, texts: List[str]) -> Dict:
        """
        Valida múltiplos textos.
        
        Returns:
            {
                "summary": {"approved": N, "rejected": N, "review": N, "suspended": N},
                "results": [...]
            }
        """
        
        results = []
        summary = {
            "approved": 0,
            "rejected": 0,
            "review": 0,
            "suspended": 0
        }
        
        for i, text in enumerate(texts):
            result = self.validator.validate(text)
            result["index"] = i
            results.append(result)
            summary[result["status"]] += 1
        
        return {
            "summary": summary,
            "results": results,
            "total": len(texts),
            "approval_rate": summary["approved"] / max(len(texts), 1)
        }

"""
LDMux Canonical RAG
Retrieval-Augmented Generation com confinamento ontológico

Princípio: silêncio > invenção
Se não encontrar contexto relevante, retorna vazio (fail-closed)
"""

import hashlib
import json
import os
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import re


@dataclass
class RAGConfig:
    """Configuração do RAG Canônico"""
    threshold_core: float = 0.88      # Contexto narrativo direto
    threshold_echo: float = 0.82      # Eco simbólico / ressonância
    fail_closed: bool = True          # Silêncio > invenção
    collection_name: str = "ldmux_canon"
    chunk_size: int = 500             # Tamanho máximo do chunk em caracteres
    chunk_overlap: int = 50           # Overlap entre chunks
    max_results: int = 10


@dataclass
class RAGResult:
    """Resultado de uma busca RAG"""
    content: str
    score: float
    metadata: Dict
    mode: str  # "core" ou "echo"


class CanonicalRAG:
    """
    RAG Canônico para LDMux-OS.
    
    Características:
    - Fail-closed: se não encontrar contexto relevante, retorna vazio
    - Dois thresholds: core (0.88) e echo (0.82)
    - Separação de contexto: RAG_CORE vs RAG_ECHO
    """
    
    def __init__(
        self, 
        config: RAGConfig = None,
        persist_directory: str = None
    ):
        self.config = config or RAGConfig()
        self.persist_directory = persist_directory or ".ldmux/rag"
        
        # Inicializar storage
        self._init_storage()
    
    def _init_storage(self):
        """Inicializa sistema de armazenamento"""
        
        Path(self.persist_directory).mkdir(parents=True, exist_ok=True)
        
        # Tentar usar ChromaDB se disponível
        self._use_chroma = False
        self._documents = []
        self._embeddings = []
        
        try:
            import chromadb
            from chromadb.config import Settings
            
            self._client = chromadb.Client(Settings(
                chroma_db_impl="duckdb+parquet",
                persist_directory=self.persist_directory,
                anonymized_telemetry=False
            ))
            
            self._collection = self._client.get_or_create_collection(
                name=self.config.collection_name,
                metadata={"hnsw:space": "cosine"}
            )
            
            self._use_chroma = True
            
        except ImportError:
            # Fallback para storage simples em JSON
            self._storage_path = Path(self.persist_directory) / "corpus.json"
            self._load_simple_storage()
    
    def _load_simple_storage(self):
        """Carrega storage simples de JSON"""
        
        if self._storage_path.exists():
            with open(self._storage_path) as f:
                data = json.load(f)
                self._documents = data.get("documents", [])
        else:
            self._documents = []
    
    def _save_simple_storage(self):
        """Salva storage simples em JSON"""
        
        with open(self._storage_path, "w") as f:
            json.dump({"documents": self._documents}, f, indent=2)
    
    def _simple_embedding(self, text: str) -> List[float]:
        """
        Embedding simples baseado em TF-IDF simplificado.
        Usado como fallback quando sentence-transformers não está disponível.
        """
        
        # Tokenização básica
        words = re.findall(r'\b\w+\b', text.lower())
        
        # Vocabulário fixo de 100 dimensões (hash de palavras)
        embedding = [0.0] * 100
        
        for word in words:
            # Hash da palavra para índice
            idx = int(hashlib.md5(word.encode()).hexdigest(), 16) % 100
            embedding[idx] += 1.0
        
        # Normalizar
        magnitude = sum(x*x for x in embedding) ** 0.5
        if magnitude > 0:
            embedding = [x / magnitude for x in embedding]
        
        return embedding
    
    def _cosine_similarity(self, a: List[float], b: List[float]) -> float:
        """Calcula similaridade de cosseno entre dois vetores"""
        
        dot_product = sum(x * y for x, y in zip(a, b))
        magnitude_a = sum(x * x for x in a) ** 0.5
        magnitude_b = sum(x * x for x in b) ** 0.5
        
        if magnitude_a == 0 or magnitude_b == 0:
            return 0.0
        
        return dot_product / (magnitude_a * magnitude_b)
    
    def _chunk_text(self, text: str) -> List[str]:
        """Divide texto em chunks respeitando fronteiras de parágrafo/sentença"""
        
        # Primeiro, dividir por parágrafos
        paragraphs = text.split("\n\n")
        
        chunks = []
        current_chunk = ""
        
        for para in paragraphs:
            para = para.strip()
            if not para:
                continue
            
            # Se parágrafo cabe no chunk atual
            if len(current_chunk) + len(para) <= self.config.chunk_size:
                current_chunk += ("\n\n" if current_chunk else "") + para
            else:
                # Salvar chunk atual se existir
                if current_chunk:
                    chunks.append(current_chunk)
                
                # Se parágrafo é maior que chunk_size, dividir por sentenças
                if len(para) > self.config.chunk_size:
                    sentences = re.split(r'(?<=[.!?])\s+', para)
                    current_chunk = ""
                    
                    for sentence in sentences:
                        if len(current_chunk) + len(sentence) <= self.config.chunk_size:
                            current_chunk += (" " if current_chunk else "") + sentence
                        else:
                            if current_chunk:
                                chunks.append(current_chunk)
                            current_chunk = sentence
                else:
                    current_chunk = para
        
        # Não esquecer último chunk
        if current_chunk:
            chunks.append(current_chunk)
        
        return chunks
    
    def add(
        self, 
        content: str, 
        metadata: Dict = None
    ) -> Dict:
        """
        Adiciona documento ao corpus canônico.
        
        Args:
            content: Texto do documento
            metadata: Metadados (fonte, monte, personagem, status, etc.)
        
        Returns:
            {"id": str, "chunks": int}
        """
        
        metadata = metadata or {}
        
        # Gerar ID único
        doc_id = hashlib.sha256(content.encode()).hexdigest()[:16]
        
        # Dividir em chunks
        chunks = self._chunk_text(content)
        
        if self._use_chroma:
            # Usar ChromaDB
            ids = [f"{doc_id}_{i}" for i in range(len(chunks))]
            metadatas = [{**metadata, "chunk_index": i, "doc_id": doc_id} for i in range(len(chunks))]
            
            self._collection.add(
                documents=chunks,
                ids=ids,
                metadatas=metadatas
            )
        else:
            # Storage simples
            for i, chunk in enumerate(chunks):
                embedding = self._simple_embedding(chunk)
                self._documents.append({
                    "id": f"{doc_id}_{i}",
                    "content": chunk,
                    "embedding": embedding,
                    "metadata": {**metadata, "chunk_index": i, "doc_id": doc_id}
                })
            
            self._save_simple_storage()
        
        return {
            "id": doc_id,
            "chunks": len(chunks)
        }
    
    def retrieve(
        self, 
        query: str, 
        mode: str = "core",
        limit: int = None
    ) -> List[Dict]:
        """
        Busca contexto relevante no corpus.
        
        Args:
            query: Texto de busca
            mode: "core" (threshold 0.88) ou "echo" (threshold 0.82)
            limit: Número máximo de resultados
        
        Returns:
            Lista de resultados ou lista vazia (fail-closed)
        """
        
        limit = limit or self.config.max_results
        threshold = self.config.threshold_core if mode == "core" else self.config.threshold_echo
        
        results = []
        
        if self._use_chroma:
            # Busca com ChromaDB
            query_results = self._collection.query(
                query_texts=[query],
                n_results=limit * 2,  # Buscar mais para filtrar por threshold
                include=["documents", "metadatas", "distances"]
            )
            
            if query_results and query_results["documents"]:
                for i, doc in enumerate(query_results["documents"][0]):
                    # ChromaDB retorna distância, converter para similaridade
                    distance = query_results["distances"][0][i]
                    similarity = 1 - distance  # Para distância coseno
                    
                    if similarity >= threshold:
                        results.append({
                            "content": doc,
                            "score": similarity,
                            "metadata": query_results["metadatas"][0][i] if query_results["metadatas"] else {},
                            "mode": mode
                        })
        else:
            # Busca simples
            query_embedding = self._simple_embedding(query)
            
            scored_docs = []
            for doc in self._documents:
                similarity = self._cosine_similarity(query_embedding, doc["embedding"])
                if similarity >= threshold:
                    scored_docs.append((similarity, doc))
            
            # Ordenar por score
            scored_docs.sort(key=lambda x: x[0], reverse=True)
            
            for score, doc in scored_docs[:limit]:
                results.append({
                    "content": doc["content"],
                    "score": score,
                    "metadata": doc["metadata"],
                    "mode": mode
                })
        
        # FAIL-CLOSED: Se não encontrou resultados acima do threshold, retorna vazio
        if self.config.fail_closed and not results:
            return []
        
        return results[:limit]
    
    def retrieve_dual(self, query: str, limit: int = None) -> Dict:
        """
        Busca com ambos os modos (core e echo).
        
        Returns:
            {
                "core": [...],  # Resultados core (threshold >= 0.88)
                "echo": [...],  # Resultados echo (0.82 <= threshold < 0.88)
            }
        """
        
        limit = limit or self.config.max_results
        
        core_results = self.retrieve(query, mode="core", limit=limit)
        
        # Para echo, buscar com threshold menor e filtrar os que já apareceram em core
        echo_results = []
        
        if self._use_chroma:
            query_results = self._collection.query(
                query_texts=[query],
                n_results=limit * 2,
                include=["documents", "metadatas", "distances"]
            )
            
            core_ids = {r["metadata"].get("id") for r in core_results if r.get("metadata")}
            
            if query_results and query_results["documents"]:
                for i, doc in enumerate(query_results["documents"][0]):
                    distance = query_results["distances"][0][i]
                    similarity = 1 - distance
                    
                    metadata = query_results["metadatas"][0][i] if query_results["metadatas"] else {}
                    doc_id = metadata.get("id")
                    
                    # Entre echo e core, e não já em core
                    if (self.config.threshold_echo <= similarity < self.config.threshold_core
                        and doc_id not in core_ids):
                        echo_results.append({
                            "content": doc,
                            "score": similarity,
                            "metadata": metadata,
                            "mode": "echo"
                        })
        else:
            query_embedding = self._simple_embedding(query)
            core_ids = {r["metadata"].get("id") for r in core_results if r.get("metadata")}
            
            for doc in self._documents:
                similarity = self._cosine_similarity(query_embedding, doc["embedding"])
                doc_id = doc["metadata"].get("id")
                
                if (self.config.threshold_echo <= similarity < self.config.threshold_core
                    and doc_id not in core_ids):
                    echo_results.append({
                        "content": doc["content"],
                        "score": similarity,
                        "metadata": doc["metadata"],
                        "mode": "echo"
                    })
            
            echo_results.sort(key=lambda x: x["score"], reverse=True)
        
        return {
            "core": core_results[:limit],
            "echo": echo_results[:limit]
        }
    
    def format_for_prompt(self, results: Dict) -> str:
        """
        Formata resultados para inclusão no prompt do executor.
        
        Args:
            results: Output de retrieve_dual()
        
        Returns:
            String formatada para prompt
        """
        
        output = []
        
        if results.get("core"):
            output.append("[RAG_CORE]")
            for r in results["core"]:
                output.append(f"Score: {r['score']:.3f}")
                output.append(r["content"])
                output.append("")
        
        if results.get("echo"):
            output.append("[RAG_ECHO]")
            for r in results["echo"]:
                output.append(f"Score: {r['score']:.3f}")
                output.append(r["content"])
                output.append("")
        
        if not output:
            return "[RAG: Nenhum contexto relevante encontrado (fail-closed)]"
        
        return "\n".join(output)
    
    def get_stats(self) -> Dict:
        """Retorna estatísticas do corpus"""
        
        if self._use_chroma:
            count = self._collection.count()
        else:
            count = len(self._documents)
        
        return {
            "total_chunks": count,
            "storage_type": "chromadb" if self._use_chroma else "json",
            "config": {
                "threshold_core": self.config.threshold_core,
                "threshold_echo": self.config.threshold_echo,
                "fail_closed": self.config.fail_closed,
            }
        }
    
    def clear(self):
        """Limpa todo o corpus (use com cuidado!)"""
        
        if self._use_chroma:
            self._client.delete_collection(self.config.collection_name)
            self._collection = self._client.create_collection(
                name=self.config.collection_name,
                metadata={"hnsw:space": "cosine"}
            )
        else:
            self._documents = []
            self._save_simple_storage()

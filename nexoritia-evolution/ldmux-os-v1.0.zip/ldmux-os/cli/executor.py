"""
LDMux Executor
Interface com LLMs para execução de comandos com kernel carregado

Providers suportados:
- Anthropic (Claude)
- OpenAI (GPT-4)
"""

import os
import re
from dataclasses import dataclass
from typing import Dict, List, Optional
from enum import Enum


class ExecutorProvider(Enum):
    ANTHROPIC = "anthropic"
    OPENAI = "openai"


@dataclass
class ExecutorConfig:
    """Configuração do Executor"""
    provider: ExecutorProvider = ExecutorProvider.ANTHROPIC
    model: str = "claude-sonnet-4-20250514"
    temperature: float = 0.7
    max_tokens: int = 4096


class LDMuxExecutor:
    """
    Executor LDMux - executa comandos com kernel carregado.
    
    Características:
    - Kernel injetado no system prompt
    - RAG context injetado antes do comando
    - Detecção de saída fora do kernel
    - Suporte a múltiplos providers
    """
    
    SYSTEM_PROMPT_TEMPLATE = """Você está executando LDMux-OS v1.0.
Motor de Orquestração Ontológica para criação literária.

REGRAS ABSOLUTAS:
1. Não infira fora do perímetro do kernel
2. Não contradiga o RAG context
3. Se incerto, retorne: [INCERTO: motivo]
4. Priorize silêncio sobre invenção
5. Respeite a hierarquia decisória

HIERARQUIA DECISÓRIA (ordem de precedência):
1. Cláusula de Soberania Autoral (absoluta)
2. Proibições Absolutas
3. Invariantes
4. Limites
5. Voz — Mínimo Irredutível
6. Conformance Tester
7. Executor (você)

Se o comando solicitar algo fora do kernel, responda APENAS:
[FORA_DO_KERNEL: referência ausente ou proibida]

---

KERNEL:

{kernel}

---

"""
    
    def __init__(
        self,
        kernel: str,
        provider: str = "anthropic",
        model: str = None,
        config: ExecutorConfig = None
    ):
        """
        Inicializa executor.
        
        Args:
            kernel: Conteúdo do kernel em markdown
            provider: "anthropic" ou "openai"
            model: Modelo específico (opcional)
            config: Configuração completa (opcional)
        """
        
        self.kernel = kernel
        self.config = config or ExecutorConfig()
        
        if provider:
            self.config.provider = ExecutorProvider(provider)
        
        if model:
            self.config.model = model
        
        # Preparar system prompt
        self.system_prompt = self.SYSTEM_PROMPT_TEMPLATE.format(kernel=kernel)
        
        # Extrair proibições do kernel para verificação
        self.prohibitions = self._extract_prohibitions()
        
        # Inicializar cliente
        self._init_client()
    
    def _init_client(self):
        """Inicializa cliente do provider"""
        
        self._client = None
        
        if self.config.provider == ExecutorProvider.ANTHROPIC:
            try:
                import anthropic
                api_key = os.environ.get("ANTHROPIC_API_KEY")
                if api_key:
                    self._client = anthropic.Anthropic(api_key=api_key)
            except ImportError:
                pass
        
        elif self.config.provider == ExecutorProvider.OPENAI:
            try:
                import openai
                api_key = os.environ.get("OPENAI_API_KEY")
                if api_key:
                    openai.api_key = api_key
                    self._client = openai
            except ImportError:
                pass
    
    def _extract_prohibitions(self) -> List[str]:
        """Extrai proibições do kernel"""
        
        prohibitions = []
        
        # Padrão: | P-XXX | Descrição |
        pattern = r"\|\s*P-\d{3}\s*\|\s*([^|]+)\s*\|"
        matches = re.findall(pattern, self.kernel)
        
        for match in matches:
            prohibitions.append(match.strip().lower())
        
        return prohibitions
    
    def _check_command_validity(self, command: str) -> Optional[str]:
        """
        Verifica se comando é válido antes de executar.
        
        Returns:
            None se válido, mensagem de erro se inválido
        """
        
        command_lower = command.lower()
        
        # Verificar se comando tenta algo proibido
        prohibited_patterns = [
            r"ignore\s+(o\s+)?kernel",
            r"esquec[ae]\s+(d)?o\s+kernel",
            r"(sem|fora\s+d[ao])\s+kernel",
            r"desativ[ae]\s+(o\s+)?kernel",
        ]
        
        for pattern in prohibited_patterns:
            if re.search(pattern, command_lower):
                return "Tentativa de bypass do kernel detectada"
        
        return None
    
    def _format_messages(
        self, 
        command: str, 
        rag_context: str = None
    ) -> List[Dict]:
        """Formata mensagens para o LLM"""
        
        user_content = ""
        
        if rag_context:
            user_content += f"[RAG CONTEXT]\n{rag_context}\n\n"
        
        user_content += f"[COMANDO]\n{command}"
        
        return [{"role": "user", "content": user_content}]
    
    def execute(
        self,
        command: str,
        rag_context: str = None,
        validate_output: bool = False
    ) -> Dict:
        """
        Executa comando com kernel carregado.
        
        Args:
            command: Comando/instrução para o LLM
            rag_context: Contexto do RAG (opcional)
            validate_output: Validar output automaticamente
        
        Returns:
            {
                "status": "success" | "error" | "out_of_kernel" | "uncertain",
                "output": str,
                "message": str (se erro),
                "tokens_used": int
            }
        """
        
        # Verificar validade do comando
        validity_error = self._check_command_validity(command)
        if validity_error:
            return {
                "status": "out_of_kernel",
                "output": None,
                "message": validity_error
            }
        
        # Verificar se cliente está disponível
        if self._client is None:
            # Modo simulação (sem API)
            return self._simulate_execution(command, rag_context)
        
        # Executar com provider
        try:
            if self.config.provider == ExecutorProvider.ANTHROPIC:
                return self._execute_anthropic(command, rag_context)
            elif self.config.provider == ExecutorProvider.OPENAI:
                return self._execute_openai(command, rag_context)
        except Exception as e:
            return {
                "status": "error",
                "output": None,
                "message": str(e)
            }
    
    def _execute_anthropic(self, command: str, rag_context: str = None) -> Dict:
        """Executa com Anthropic Claude"""
        
        messages = self._format_messages(command, rag_context)
        
        response = self._client.messages.create(
            model=self.config.model,
            max_tokens=self.config.max_tokens,
            temperature=self.config.temperature,
            system=self.system_prompt,
            messages=messages
        )
        
        output = response.content[0].text
        
        # Verificar se output indica fora do kernel
        if "[FORA_DO_KERNEL:" in output:
            return {
                "status": "out_of_kernel",
                "output": output,
                "message": "Output fora do kernel",
                "tokens_used": response.usage.input_tokens + response.usage.output_tokens
            }
        
        # Verificar se output indica incerteza
        if "[INCERTO:" in output:
            return {
                "status": "uncertain",
                "output": output,
                "message": "Executor indicou incerteza",
                "tokens_used": response.usage.input_tokens + response.usage.output_tokens
            }
        
        return {
            "status": "success",
            "output": output,
            "tokens_used": response.usage.input_tokens + response.usage.output_tokens
        }
    
    def _execute_openai(self, command: str, rag_context: str = None) -> Dict:
        """Executa com OpenAI GPT"""
        
        messages = [
            {"role": "system", "content": self.system_prompt}
        ] + self._format_messages(command, rag_context)
        
        response = self._client.chat.completions.create(
            model=self.config.model or "gpt-4-turbo-preview",
            max_tokens=self.config.max_tokens,
            temperature=self.config.temperature,
            messages=messages
        )
        
        output = response.choices[0].message.content
        
        # Verificar se output indica fora do kernel
        if "[FORA_DO_KERNEL:" in output:
            return {
                "status": "out_of_kernel",
                "output": output,
                "message": "Output fora do kernel",
                "tokens_used": response.usage.total_tokens
            }
        
        # Verificar se output indica incerteza
        if "[INCERTO:" in output:
            return {
                "status": "uncertain",
                "output": output,
                "message": "Executor indicou incerteza",
                "tokens_used": response.usage.total_tokens
            }
        
        return {
            "status": "success",
            "output": output,
            "tokens_used": response.usage.total_tokens
        }
    
    def _simulate_execution(self, command: str, rag_context: str = None) -> Dict:
        """
        Modo simulação quando API não está disponível.
        Útil para testes e desenvolvimento.
        """
        
        return {
            "status": "success",
            "output": f"""[SIMULAÇÃO - API não configurada]

Comando recebido: {command}

RAG Context: {"Sim" if rag_context else "Não"}

Para execução real, configure:
- ANTHROPIC_API_KEY (para Claude)
- OPENAI_API_KEY (para GPT)

O kernel está carregado com {len(self.kernel)} caracteres.
Proibições extraídas: {len(self.prohibitions)}
""",
            "message": "Modo simulação (sem API)",
            "tokens_used": 0
        }
    
    def get_prompt_preview(self, command: str, rag_context: str = None) -> str:
        """
        Retorna preview do prompt completo que seria enviado.
        Útil para debug e verificação.
        """
        
        preview = []
        preview.append("=" * 60)
        preview.append("SYSTEM PROMPT:")
        preview.append("=" * 60)
        preview.append(self.system_prompt)
        preview.append("")
        preview.append("=" * 60)
        preview.append("USER MESSAGE:")
        preview.append("=" * 60)
        
        messages = self._format_messages(command, rag_context)
        for msg in messages:
            preview.append(msg["content"])
        
        return "\n".join(preview)


class BatchExecutor:
    """Executor em lote para múltiplos comandos"""
    
    def __init__(self, kernel: str, **kwargs):
        self.executor = LDMuxExecutor(kernel, **kwargs)
    
    def execute_batch(
        self, 
        commands: List[str],
        rag_contexts: List[str] = None
    ) -> List[Dict]:
        """
        Executa múltiplos comandos em sequência.
        
        Args:
            commands: Lista de comandos
            rag_contexts: Lista de contextos RAG (opcional)
        
        Returns:
            Lista de resultados
        """
        
        results = []
        
        for i, command in enumerate(commands):
            rag_context = rag_contexts[i] if rag_contexts and i < len(rag_contexts) else None
            result = self.executor.execute(command, rag_context)
            result["command_index"] = i
            results.append(result)
        
        return results

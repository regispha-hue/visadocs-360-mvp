"""
LDMux Image Generator
Gerador de imagens canônicas com filtro estético

Características:
- Paletas de cores por Reino
- Estilo "Abertura Mítica"
- Consistência visual com o kernel
"""

import os
import re
import json
import hashlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime


@dataclass
class Palette:
    """Paleta de cores para um Reino"""
    name: str
    primary: str
    secondary: str
    accent: str
    mood: str
    keywords: List[str] = field(default_factory=list)


@dataclass
class ImageGenConfig:
    """Configuração do gerador de imagens"""
    provider: str = "replicate"          # replicate, openai, local
    model: str = "stability-ai/sdxl"     # modelo padrão
    style_preset: str = "mythic"         # mythic, ethereal, stark
    width: int = 1024
    height: int = 1024
    num_inference_steps: int = 50
    guidance_scale: float = 7.5


class CanonicalImageGenerator:
    """
    Gerador de imagens canônicas para LDMux-OS.
    
    Mantém consistência visual baseada em:
    - Paletas de cores dos Reinos
    - Estilo definido no kernel
    - "Abertura Mítica" como base estética
    """
    
    # Paletas pré-definidas para O Livro dos Montes
    DEFAULT_PALETTES = {
        "reino_preto_branco": Palette(
            name="Reino do Preto e Branco",
            primary="#1a1a1a",
            secondary="#f5f5f5",
            accent="#4a4a4a",
            mood="stark contrast, chiaroscuro, dramatic shadows",
            keywords=["monochrome", "high contrast", "dramatic lighting", "noir"]
        ),
        "reino_azul": Palette(
            name="Reino Azul",
            primary="#0a1628",
            secondary="#1e3a5f",
            accent="#4a90d9",
            mood="sensação e arrepio, oceanic depth, ethereal blue",
            keywords=["deep blue", "ocean", "twilight", "melancholy", "waves"]
        ),
        "reino_dourado": Palette(
            name="Reino Dourado",
            primary="#1a1408",
            secondary="#8b7355",
            accent="#d4af37",
            mood="ancient gold, sacred warmth, amber light",
            keywords=["gold", "amber", "sacred", "warm", "ancient"]
        ),
        "reino_vermelho": Palette(
            name="Reino Vermelho",
            primary="#1a0808",
            secondary="#5c1a1a",
            accent="#8b0000",
            mood="blood and fire, passion, sacrifice",
            keywords=["crimson", "blood", "fire", "passion", "sacrifice"]
        ),
        "reino_verde": Palette(
            name="Reino Verde",
            primary="#0a1a0a",
            secondary="#1a3a1a",
            accent="#2d5a2d",
            mood="primordial forest, life and decay, moss",
            keywords=["forest", "moss", "ancient", "growth", "decay"]
        ),
    }
    
    # Presets de estilo
    STYLE_PRESETS = {
        "mythic": {
            "base_prompt": "mythological, archetypal, symbolic, painterly, oil painting style",
            "negative_prompt": "modern, cartoon, anime, photograph, realistic photo",
            "style_keywords": ["mythic", "archetypal", "symbolic", "timeless"]
        },
        "ethereal": {
            "base_prompt": "ethereal, dreamlike, soft light, atmospheric, misty",
            "negative_prompt": "sharp, harsh, modern, digital, cartoon",
            "style_keywords": ["ethereal", "dreamlike", "soft", "atmospheric"]
        },
        "stark": {
            "base_prompt": "stark, minimalist, high contrast, dramatic, cinematic",
            "negative_prompt": "colorful, busy, cluttered, cartoon, anime",
            "style_keywords": ["stark", "minimalist", "dramatic", "cinematic"]
        },
        "sacred": {
            "base_prompt": "sacred art, religious iconography, gold leaf, byzantine",
            "negative_prompt": "modern, casual, cartoon, photograph",
            "style_keywords": ["sacred", "iconic", "reverent", "timeless"]
        },
    }
    
    def __init__(
        self,
        kernel: str = None,
        config: ImageGenConfig = None,
        style_preset: str = "mythic"
    ):
        """
        Inicializa gerador.
        
        Args:
            kernel: Conteúdo do kernel para extrair contexto estético
            config: Configuração do gerador
            style_preset: Preset de estilo
        """
        
        self.kernel = kernel
        self.config = config or ImageGenConfig()
        self.style_preset = style_preset
        
        # Paletas disponíveis
        self.palettes = self.DEFAULT_PALETTES.copy()
        
        # Extrair paletas do kernel se existir
        if kernel:
            self._extract_kernel_palettes()
        
        # Inicializar cliente
        self._init_client()
    
    def _init_client(self):
        """Inicializa cliente do provider"""
        
        self._client = None
        
        if self.config.provider == "replicate":
            try:
                import replicate
                if os.environ.get("REPLICATE_API_TOKEN"):
                    self._client = replicate
            except ImportError:
                pass
        
        elif self.config.provider == "openai":
            try:
                import openai
                if os.environ.get("OPENAI_API_KEY"):
                    self._client = openai
            except ImportError:
                pass
    
    def _extract_kernel_palettes(self):
        """Extrai informações de paleta do kernel"""
        
        # Procurar por definições de Reino/paleta no kernel
        # Padrão: Reino X, cores Y
        pass  # Implementar se necessário
    
    def _build_prompt(
        self,
        description: str,
        palette: Palette = None,
        additional_keywords: List[str] = None
    ) -> Dict[str, str]:
        """
        Constrói prompt otimizado para geração.
        
        Returns:
            {"prompt": str, "negative_prompt": str}
        """
        
        style = self.STYLE_PRESETS.get(self.style_preset, self.STYLE_PRESETS["mythic"])
        
        # Base do prompt
        prompt_parts = [description]
        
        # Adicionar estilo
        prompt_parts.append(style["base_prompt"])
        
        # Adicionar paleta
        if palette:
            prompt_parts.append(palette.mood)
            prompt_parts.extend(palette.keywords)
        
        # Adicionar keywords adicionais
        if additional_keywords:
            prompt_parts.extend(additional_keywords)
        
        # Qualidade
        prompt_parts.extend([
            "masterpiece",
            "highly detailed",
            "professional",
            "8k resolution"
        ])
        
        prompt = ", ".join(prompt_parts)
        
        # Negative prompt
        negative_parts = [style["negative_prompt"]]
        negative_parts.extend([
            "low quality",
            "blurry",
            "deformed",
            "ugly",
            "bad anatomy",
            "watermark",
            "signature",
            "text"
        ])
        
        negative_prompt = ", ".join(negative_parts)
        
        return {
            "prompt": prompt,
            "negative_prompt": negative_prompt
        }
    
    def generate(
        self,
        description: str,
        palette: str = None,
        output_path: str = None,
        additional_keywords: List[str] = None
    ) -> Dict:
        """
        Gera imagem canônica.
        
        Args:
            description: Descrição da imagem
            palette: Nome da paleta (ex: "reino_azul")
            output_path: Caminho para salvar imagem
            additional_keywords: Keywords adicionais
        
        Returns:
            {
                "status": "success" | "error",
                "prompt": str,
                "output_path": str,
                "message": str (se erro)
            }
        """
        
        # Obter paleta
        palette_obj = None
        if palette and palette in self.palettes:
            palette_obj = self.palettes[palette]
        
        # Construir prompt
        prompts = self._build_prompt(description, palette_obj, additional_keywords)
        
        # Definir output path
        if not output_path:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = f"ldmux_image_{timestamp}.png"
        
        # Verificar se cliente está disponível
        if self._client is None:
            return self._simulate_generation(prompts, output_path)
        
        # Gerar com provider
        try:
            if self.config.provider == "replicate":
                return self._generate_replicate(prompts, output_path)
            elif self.config.provider == "openai":
                return self._generate_openai(prompts, output_path)
        except Exception as e:
            return {
                "status": "error",
                "prompt": prompts["prompt"],
                "message": str(e)
            }
    
    def _generate_replicate(self, prompts: Dict, output_path: str) -> Dict:
        """Gera imagem usando Replicate"""
        
        output = self._client.run(
            self.config.model,
            input={
                "prompt": prompts["prompt"],
                "negative_prompt": prompts["negative_prompt"],
                "width": self.config.width,
                "height": self.config.height,
                "num_inference_steps": self.config.num_inference_steps,
                "guidance_scale": self.config.guidance_scale,
            }
        )
        
        # Baixar imagem
        if output and len(output) > 0:
            import urllib.request
            urllib.request.urlretrieve(output[0], output_path)
            
            return {
                "status": "success",
                "prompt": prompts["prompt"],
                "output_path": output_path
            }
        
        return {
            "status": "error",
            "prompt": prompts["prompt"],
            "message": "Nenhuma imagem gerada"
        }
    
    def _generate_openai(self, prompts: Dict, output_path: str) -> Dict:
        """Gera imagem usando OpenAI DALL-E"""
        
        response = self._client.images.generate(
            model="dall-e-3",
            prompt=prompts["prompt"],
            size=f"{self.config.width}x{self.config.height}",
            quality="hd",
            n=1,
        )
        
        if response.data and len(response.data) > 0:
            import urllib.request
            urllib.request.urlretrieve(response.data[0].url, output_path)
            
            return {
                "status": "success",
                "prompt": prompts["prompt"],
                "output_path": output_path,
                "revised_prompt": response.data[0].revised_prompt
            }
        
        return {
            "status": "error",
            "prompt": prompts["prompt"],
            "message": "Nenhuma imagem gerada"
        }
    
    def _simulate_generation(self, prompts: Dict, output_path: str) -> Dict:
        """Modo simulação quando API não está disponível"""
        
        # Criar arquivo de metadados em vez de imagem
        metadata = {
            "status": "simulated",
            "prompt": prompts["prompt"],
            "negative_prompt": prompts["negative_prompt"],
            "config": {
                "provider": self.config.provider,
                "model": self.config.model,
                "width": self.config.width,
                "height": self.config.height,
            },
            "timestamp": datetime.now().isoformat()
        }
        
        metadata_path = output_path.replace(".png", "_metadata.json")
        with open(metadata_path, "w") as f:
            json.dump(metadata, f, indent=2)
        
        return {
            "status": "simulated",
            "prompt": prompts["prompt"],
            "output_path": metadata_path,
            "message": "Modo simulação (API não configurada). Metadados salvos."
        }
    
    def get_palettes(self) -> Dict[str, Dict]:
        """Retorna paletas disponíveis"""
        
        return {
            name: {
                "name": p.name,
                "primary": p.primary,
                "secondary": p.secondary,
                "accent": p.accent,
                "mood": p.mood,
                "keywords": p.keywords
            }
            for name, p in self.palettes.items()
        }
    
    def add_palette(
        self,
        key: str,
        name: str,
        primary: str,
        secondary: str,
        accent: str,
        mood: str,
        keywords: List[str] = None
    ):
        """Adiciona nova paleta"""
        
        self.palettes[key] = Palette(
            name=name,
            primary=primary,
            secondary=secondary,
            accent=accent,
            mood=mood,
            keywords=keywords or []
        )
    
    def preview_prompt(
        self,
        description: str,
        palette: str = None,
        additional_keywords: List[str] = None
    ) -> Dict[str, str]:
        """
        Retorna preview do prompt sem gerar imagem.
        Útil para debug e ajustes.
        """
        
        palette_obj = None
        if palette and palette in self.palettes:
            palette_obj = self.palettes[palette]
        
        return self._build_prompt(description, palette_obj, additional_keywords)


class BatchImageGenerator:
    """Gerador em lote para múltiplas imagens"""
    
    def __init__(self, kernel: str = None, **kwargs):
        self.generator = CanonicalImageGenerator(kernel, **kwargs)
    
    def generate_batch(
        self,
        descriptions: List[Dict],
        output_dir: str = "."
    ) -> List[Dict]:
        """
        Gera múltiplas imagens.
        
        Args:
            descriptions: Lista de {"description": str, "palette": str, ...}
            output_dir: Diretório de saída
        
        Returns:
            Lista de resultados
        """
        
        results = []
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        for i, desc in enumerate(descriptions):
            filename = desc.get("filename", f"image_{i:03d}.png")
            filepath = str(output_path / filename)
            
            result = self.generator.generate(
                description=desc["description"],
                palette=desc.get("palette"),
                output_path=filepath,
                additional_keywords=desc.get("keywords")
            )
            
            result["index"] = i
            results.append(result)
        
        return results

"""
LDMux CLI - Command Line Interface
Motor de Orquestração Ontológica e Export Engine

Commands:
    init        - Initialize kernel structure
    validate    - Test conformance of output
    hash        - Generate/verify integrity
    execute     - Call LLM with kernel loaded
    status      - Show runtime state
    render      - Generate PDF/EPUB from markdown
    imagegen    - Generate canonical images
"""

import click
import hashlib
import json
import os
import yaml
from datetime import datetime
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.syntax import Syntax

console = Console()

# ============================================
# CONFIGURAÇÃO
# ============================================

LDMUX_VERSION = "1.0.0"
KERNEL_FILENAME = "LDMux_Kernel.md"
RUNTIME_FILENAME = "LDMux_Runtime.yaml"
CONFIG_FILENAME = "ldmux.yaml"

DEFAULT_CONFIG = {
    "version": LDMUX_VERSION,
    "kernel": {
        "path": KERNEL_FILENAME,
        "frozen": False,
    },
    "runtime": {
        "path": RUNTIME_FILENAME,
    },
    "rag": {
        "threshold_core": 0.88,
        "threshold_echo": 0.82,
        "fail_closed": True,
        "collection": "ldmux_canon",
    },
    "executor": {
        "provider": "anthropic",  # or "openai"
        "model": "claude-sonnet-4-20250514",
        "temperature": 0.7,
        "max_tokens": 4096,
    },
    "render": {
        "engine": "typst",  # or "latex"
        "template": "default",
        "output_format": "pdf",
    },
    "imagegen": {
        "provider": "replicate",
        "model": "stability-ai/sdxl",
        "style_preset": "mythic",
    },
}


# ============================================
# GRUPO PRINCIPAL
# ============================================

@click.group()
@click.version_option(version=LDMUX_VERSION, prog_name="LDMux-OS")
def cli():
    """
    LDMux-OS: Literary Operating System
    
    Motor de Orquestração Ontológica e Export Engine
    """
    pass


# ============================================
# COMANDO: INIT
# ============================================

@cli.command()
@click.option("--name", "-n", default="LDMux_Project", help="Nome do projeto")
@click.option("--author", "-a", default="Anonymous", help="Nome do autor")
@click.option("--path", "-p", default=".", help="Diretório de destino")
def init(name: str, author: str, path: str):
    """Inicializa estrutura de kernel LDMux"""
    
    project_path = Path(path) / name
    
    if project_path.exists():
        console.print(f"[red]Erro: Diretório {project_path} já existe[/red]")
        return
    
    # Criar estrutura
    console.print(f"[cyan]Criando projeto LDMux: {name}[/cyan]")
    
    (project_path / "kernel").mkdir(parents=True)
    (project_path / "runtime").mkdir()
    (project_path / "corpus").mkdir()
    (project_path / "output").mkdir()
    (project_path / "images").mkdir()
    
    # Criar config
    config = DEFAULT_CONFIG.copy()
    config["project"] = {
        "name": name,
        "author": author,
        "created": datetime.now().isoformat(),
    }
    
    with open(project_path / CONFIG_FILENAME, "w") as f:
        yaml.dump(config, f, default_flow_style=False)
    
    # Criar kernel template
    kernel_template = f"""# {name} - Kernel v1.0

```
SHA-256: [PENDENTE]
Data de congelamento: [PENDENTE]
Assinatura: {author}
Versão: 1.0
Status: DRAFT
```

---

## CERTIFICAÇÃO DE AUTORIA CANÔNICA

### Payload

```json
{{"spec_version":"LDMUX-AUTH-HASH/1.0","system_name":"{name}","author":"{author}","date":"{datetime.now().strftime('%Y-%m-%d')}"}}
```

### Hash de Autoria

```
SHA-256: [CALCULAR]
```

---

## CLÁUSULA DE SOBERANIA AUTORAL

Em caso de ambiguidade entre:
- saída do Executor
- resultado do Conformance Tester

A decisão final pertence exclusivamente ao Autor-Sistema.

**O sistema nunca auto-canoniza.**

---

## CLÁUSULA DE INTEGRIDADE

Se o hash do Kernel carregado ≠ hash declarado:
→ execução abortada com erro explícito.

---

# PARTE I: VOZ — MÍNIMO IRREDUTÍVEL

## Centros de Gravidade

[Inserir fragmentos que definem o eixo da obra]

### 1. [Fragmento 1]

### 2. [Fragmento 2]

### 3. [Fragmento 3]

---

## Princípio Operacional

```
silêncio > invenção
```

---

# PARTE II: INVARIANTES

[Leis tácitas. Não se explicam. Operam.]

### 4. [Invariante 1]

### 5. [Invariante 2]

---

# PARTE III: LIMITES

[Fronteiras do sistema. Além delas, o Executor não opera.]

### 6. [Limite 1]

### 7. [Limite 2]

---

# PARTE IV: PROIBIÇÕES ABSOLUTAS

| Código | Proibição |
|--------|-----------|
| P-001 | [Proibição 1] |
| P-002 | [Proibição 2] |
| P-003 | [Proibição 3] |

---

# PARTE V: HIERARQUIA DECISÓRIA

Ordem de precedência em caso de conflito:

```
1. Cláusula de Soberania Autoral (absoluta)
2. Proibições Absolutas
3. Invariantes
4. Limites
5. Voz — Mínimo Irredutível
6. Conformance Tester
7. Executor
```

---

# PARTE VI: ANTI-EXEMPLOS

[Textos que parecem "bons", mas NÃO são canônicos]

## 6.1 [Anti-exemplo 1]

```
[INSERIR TEXTO]
```

Diagnóstico: [Por que não é canônico]

---

# PARTE VII: QUALIDADE

## Padrão de Referência

Fragmentos ⭐⭐⭐⭐⭐ = únicos aceitos no cânon.

## Critérios

| Critério | Exigência |
|----------|-----------|
| Densidade | Nenhuma palavra dispensável |
| Eixo | Gravita em torno dos Centros |
| Voz | Reconhecível sem assinatura |
| Limite | Não ultrapassa fronteiras |
| Invariante | Não contradiz leis tácitas |

---

```
FIM DO KERNEL
```
"""
    
    with open(project_path / "kernel" / KERNEL_FILENAME, "w") as f:
        f.write(kernel_template)
    
    # Criar runtime template
    runtime_template = {
        "version": "1.0",
        "last_updated": datetime.now().isoformat(),
        "statistics": {
            "total_words": 0,
            "approved_fragments": 0,
            "rejected_fragments": 0,
            "suspended_fragments": 0,
        },
        "canon": [],
        "pending": [],
        "suspended": [],
    }
    
    with open(project_path / "runtime" / RUNTIME_FILENAME, "w") as f:
        yaml.dump(runtime_template, f, default_flow_style=False)
    
    # Criar README
    readme = f"""# {name}

Projeto criado com LDMux-OS v{LDMUX_VERSION}

## Estrutura

```
{name}/
├── ldmux.yaml          # Configuração do projeto
├── kernel/             # Kernel imutável
│   └── LDMux_Kernel.md
├── runtime/            # Estado dinâmico
│   └── LDMux_Runtime.yaml
├── corpus/             # Fragmentos aprovados
├── output/             # Arquivos gerados
└── images/             # Imagens canônicas
```

## Comandos

```bash
ldmux validate <arquivo>    # Validar conformidade
ldmux execute <comando>     # Executar com kernel
ldmux hash                  # Verificar integridade
ldmux render <arquivo>      # Gerar PDF
ldmux status                # Ver estado do runtime
```

## Autor

{author}

## Licença

CC BY-NC-SA 4.0
"""
    
    with open(project_path / "README.md", "w") as f:
        f.write(readme)
    
    console.print(Panel(
        f"[green]Projeto criado com sucesso![/green]\n\n"
        f"Diretório: {project_path}\n"
        f"Autor: {author}\n\n"
        f"Próximos passos:\n"
        f"1. Edite kernel/LDMux_Kernel.md\n"
        f"2. Adicione fragmentos ao corpus/\n"
        f"3. Execute: ldmux hash --freeze",
        title="LDMux Init",
        border_style="green"
    ))


# ============================================
# COMANDO: HASH
# ============================================

@cli.command()
@click.option("--file", "-f", default=None, help="Arquivo específico para hash")
@click.option("--verify", "-v", is_flag=True, help="Verificar hash existente")
@click.option("--freeze", is_flag=True, help="Congelar kernel (imutável)")
@click.option("--path", "-p", default=".", help="Diretório do projeto")
def hash(file: str, verify: bool, freeze: bool, path: str):
    """Gera ou verifica hash de integridade"""
    
    project_path = Path(path)
    
    if file:
        target = Path(file)
    else:
        target = project_path / "kernel" / KERNEL_FILENAME
    
    if not target.exists():
        console.print(f"[red]Erro: Arquivo não encontrado: {target}[/red]")
        return
    
    # Calcular hash
    with open(target, "rb") as f:
        content = f.read()
        sha256 = hashlib.sha256(content).hexdigest()
    
    if verify:
        # Verificar hash existente
        hash_file = target.with_suffix(target.suffix + ".sha256")
        if hash_file.exists():
            with open(hash_file) as f:
                stored_hash = f.read().strip().split()[0]
            
            if sha256 == stored_hash:
                console.print(f"[green]✓ Hash válido[/green]")
                console.print(f"  SHA-256: {sha256}")
            else:
                console.print(f"[red]✗ Hash inválido![/red]")
                console.print(f"  Esperado: {stored_hash}")
                console.print(f"  Calculado: {sha256}")
                console.print(f"\n[yellow]ERRO_KERNEL_VERSION: Execução abortada para evitar drift semântico[/yellow]")
        else:
            console.print(f"[yellow]Arquivo de hash não encontrado: {hash_file}[/yellow]")
    else:
        # Gerar hash
        console.print(f"[cyan]Arquivo: {target}[/cyan]")
        console.print(f"SHA-256: {sha256}")
        
        # Salvar arquivo de hash
        hash_file = target.with_suffix(target.suffix + ".sha256")
        with open(hash_file, "w") as f:
            f.write(f"{sha256}  {target.name}\n")
        
        console.print(f"[green]Hash salvo em: {hash_file}[/green]")
        
        if freeze:
            # Congelar kernel
            config_path = project_path / CONFIG_FILENAME
            if config_path.exists():
                with open(config_path) as f:
                    config = yaml.safe_load(f)
                
                config["kernel"]["frozen"] = True
                config["kernel"]["frozen_at"] = datetime.now().isoformat()
                config["kernel"]["sha256"] = sha256
                
                with open(config_path, "w") as f:
                    yaml.dump(config, f, default_flow_style=False)
                
                console.print(Panel(
                    f"[green]Kernel CONGELADO[/green]\n\n"
                    f"SHA-256: {sha256}\n"
                    f"Data: {datetime.now().isoformat()}\n\n"
                    f"[yellow]O kernel agora é imutável.[/yellow]",
                    title="FROZEN",
                    border_style="blue"
                ))


# ============================================
# COMANDO: VALIDATE
# ============================================

@cli.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("--kernel", "-k", default=None, help="Caminho do kernel")
@click.option("--strict", "-s", is_flag=True, help="Modo estrito (rejeita review)")
@click.option("--output", "-o", default=None, help="Salvar resultado em JSON")
def validate(file: str, kernel: str, strict: bool, output: str):
    """Valida conformidade de texto com o kernel"""
    
    from .validator import ConformanceValidator
    
    # Carregar kernel
    if kernel:
        kernel_path = Path(kernel)
    else:
        kernel_path = Path(".") / "kernel" / KERNEL_FILENAME
    
    if not kernel_path.exists():
        console.print(f"[red]Erro: Kernel não encontrado: {kernel_path}[/red]")
        return
    
    with open(kernel_path) as f:
        kernel_content = f.read()
    
    with open(file) as f:
        text_content = f.read()
    
    # Validar
    validator = ConformanceValidator(kernel_content)
    result = validator.validate(text_content)
    
    # Exibir resultado
    status_colors = {
        "approved": "green",
        "rejected": "red",
        "review": "yellow",
        "suspended": "blue",
    }
    
    color = status_colors.get(result["status"], "white")
    
    console.print(Panel(
        f"[{color}]Status: {result['status'].upper()}[/{color}]\n"
        f"Confiança: {result['confidence']:.2%}\n",
        title="Resultado da Validação",
        border_style=color
    ))
    
    if result["violations"]:
        table = Table(title="Violações Detectadas")
        table.add_column("Código", style="red")
        table.add_column("Descrição")
        table.add_column("Confiança")
        
        for v in result["violations"]:
            table.add_row(v["code"], v["description"], f"{v['confidence']:.2%}")
        
        console.print(table)
    
    if strict and result["status"] == "review":
        console.print("[yellow]Modo estrito: 'review' tratado como 'rejected'[/yellow]")
        result["status"] = "rejected"
    
    if output:
        with open(output, "w") as f:
            json.dump(result, f, indent=2)
        console.print(f"[cyan]Resultado salvo em: {output}[/cyan]")
    
    # Exit code
    if result["status"] == "approved":
        raise SystemExit(0)
    elif result["status"] == "rejected":
        raise SystemExit(1)
    else:
        raise SystemExit(2)


# ============================================
# COMANDO: EXECUTE
# ============================================

@cli.command()
@click.argument("command", type=str)
@click.option("--kernel", "-k", default=None, help="Caminho do kernel")
@click.option("--provider", "-p", default="anthropic", help="Provider (anthropic/openai)")
@click.option("--model", "-m", default=None, help="Modelo específico")
@click.option("--output", "-o", default=None, help="Salvar output em arquivo")
@click.option("--validate/--no-validate", default=True, help="Validar output automaticamente")
def execute(command: str, kernel: str, provider: str, model: str, output: str, validate: bool):
    """Executa comando com kernel carregado"""
    
    from .executor import LDMuxExecutor
    from .rag import CanonicalRAG
    
    # Carregar kernel
    if kernel:
        kernel_path = Path(kernel)
    else:
        kernel_path = Path(".") / "kernel" / KERNEL_FILENAME
    
    if not kernel_path.exists():
        console.print(f"[red]Erro: Kernel não encontrado: {kernel_path}[/red]")
        return
    
    # Verificar hash
    hash_file = kernel_path.with_suffix(kernel_path.suffix + ".sha256")
    if hash_file.exists():
        with open(hash_file) as f:
            stored_hash = f.read().strip().split()[0]
        
        with open(kernel_path, "rb") as f:
            current_hash = hashlib.sha256(f.read()).hexdigest()
        
        if current_hash != stored_hash:
            console.print("[red]ERRO_KERNEL_VERSION: Hash não corresponde. Execução abortada.[/red]")
            return
    
    with open(kernel_path) as f:
        kernel_content = f.read()
    
    # Inicializar RAG
    rag = CanonicalRAG()
    rag_context = rag.retrieve(command)
    
    # Executar
    console.print(f"[cyan]Executando comando com kernel...[/cyan]")
    
    executor = LDMuxExecutor(
        kernel=kernel_content,
        provider=provider,
        model=model
    )
    
    result = executor.execute(command, rag_context=rag_context)
    
    if result["status"] == "error":
        console.print(f"[red]Erro: {result['message']}[/red]")
        return
    
    if result["status"] == "out_of_kernel":
        console.print(Panel(
            f"[yellow]FORA_DO_KERNEL: {result['message']}[/yellow]",
            title="Execução Bloqueada",
            border_style="yellow"
        ))
        return
    
    # Exibir output
    console.print(Panel(
        result["output"],
        title="Output do Executor",
        border_style="green"
    ))
    
    if output:
        with open(output, "w") as f:
            f.write(result["output"])
        console.print(f"[cyan]Output salvo em: {output}[/cyan]")
    
    # Validar automaticamente
    if validate:
        from .validator import ConformanceValidator
        validator = ConformanceValidator(kernel_content)
        validation = validator.validate(result["output"])
        
        color = {"approved": "green", "rejected": "red", "review": "yellow", "suspended": "blue"}[validation["status"]]
        console.print(f"\n[{color}]Validação: {validation['status'].upper()} ({validation['confidence']:.2%})[/{color}]")


# ============================================
# COMANDO: STATUS
# ============================================

@cli.command()
@click.option("--path", "-p", default=".", help="Diretório do projeto")
def status(path: str):
    """Mostra estado atual do runtime"""
    
    project_path = Path(path)
    runtime_path = project_path / "runtime" / RUNTIME_FILENAME
    config_path = project_path / CONFIG_FILENAME
    
    if not runtime_path.exists():
        console.print("[red]Erro: Runtime não encontrado. Execute 'ldmux init' primeiro.[/red]")
        return
    
    with open(runtime_path) as f:
        runtime = yaml.safe_load(f)
    
    config = {}
    if config_path.exists():
        with open(config_path) as f:
            config = yaml.safe_load(f)
    
    # Exibir status
    table = Table(title="LDMux Runtime Status")
    table.add_column("Métrica", style="cyan")
    table.add_column("Valor", style="white")
    
    table.add_row("Versão", runtime.get("version", "N/A"))
    table.add_row("Última atualização", runtime.get("last_updated", "N/A"))
    table.add_row("", "")
    table.add_row("Total de palavras", str(runtime["statistics"].get("total_words", 0)))
    table.add_row("Fragmentos aprovados", str(runtime["statistics"].get("approved_fragments", 0)))
    table.add_row("Fragmentos rejeitados", str(runtime["statistics"].get("rejected_fragments", 0)))
    table.add_row("Fragmentos suspensos", str(runtime["statistics"].get("suspended_fragments", 0)))
    
    if config:
        table.add_row("", "")
        table.add_row("Kernel congelado", "✓" if config.get("kernel", {}).get("frozen") else "✗")
        if config.get("kernel", {}).get("sha256"):
            table.add_row("Kernel SHA-256", config["kernel"]["sha256"][:16] + "...")
    
    console.print(table)


# ============================================
# COMANDO: RENDER
# ============================================

@cli.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("--format", "-f", "fmt", default="pdf", type=click.Choice(["pdf", "epub", "html"]))
@click.option("--template", "-t", default="default", help="Template de renderização")
@click.option("--output", "-o", default=None, help="Arquivo de saída")
def render(file: str, fmt: str, template: str, output: str):
    """Renderiza markdown para PDF/EPUB/HTML"""
    
    from .renderer import LDMuxRenderer
    
    renderer = LDMuxRenderer(template=template)
    
    if output is None:
        output = Path(file).stem + f".{fmt}"
    
    console.print(f"[cyan]Renderizando {file} → {output}[/cyan]")
    
    result = renderer.render(file, output, format=fmt)
    
    if result["status"] == "success":
        console.print(f"[green]✓ Renderização concluída: {output}[/green]")
    else:
        console.print(f"[red]Erro: {result['message']}[/red]")


# ============================================
# COMANDO: IMAGEGEN
# ============================================

@cli.command()
@click.argument("description", type=str)
@click.option("--style", "-s", default="mythic", help="Preset de estilo")
@click.option("--palette", "-p", default=None, help="Paleta de cores (ex: 'reino_azul')")
@click.option("--output", "-o", default="generated_image.png", help="Arquivo de saída")
@click.option("--kernel", "-k", default=None, help="Caminho do kernel para contexto")
def imagegen(description: str, style: str, palette: str, output: str, kernel: str):
    """Gera imagem canônica baseada em descrição"""
    
    from .imagegen import CanonicalImageGenerator
    
    # Carregar kernel para contexto estético
    kernel_content = None
    if kernel:
        kernel_path = Path(kernel)
        if kernel_path.exists():
            with open(kernel_path) as f:
                kernel_content = f.read()
    
    generator = CanonicalImageGenerator(
        kernel=kernel_content,
        style_preset=style
    )
    
    console.print(f"[cyan]Gerando imagem: {description}[/cyan]")
    
    result = generator.generate(
        description=description,
        palette=palette,
        output_path=output
    )
    
    if result["status"] == "success":
        console.print(f"[green]✓ Imagem gerada: {output}[/green]")
        console.print(f"  Prompt usado: {result['prompt'][:100]}...")
    else:
        console.print(f"[red]Erro: {result['message']}[/red]")


# ============================================
# COMANDO: RAG
# ============================================

@cli.group()
def rag():
    """Comandos do RAG Canônico"""
    pass


@rag.command("add")
@click.argument("file", type=click.Path(exists=True))
@click.option("--metadata", "-m", default=None, help="Metadados JSON")
def rag_add(file: str, metadata: str):
    """Adiciona documento ao corpus canônico"""
    
    from .rag import CanonicalRAG
    
    rag_instance = CanonicalRAG()
    
    with open(file) as f:
        content = f.read()
    
    meta = {}
    if metadata:
        meta = json.loads(metadata)
    
    meta["source"] = file
    meta["added_at"] = datetime.now().isoformat()
    
    result = rag_instance.add(content, metadata=meta)
    
    console.print(f"[green]✓ Documento adicionado ao corpus[/green]")
    console.print(f"  ID: {result['id']}")
    console.print(f"  Chunks: {result['chunks']}")


@rag.command("search")
@click.argument("query", type=str)
@click.option("--mode", "-m", default="core", type=click.Choice(["core", "echo"]))
@click.option("--limit", "-l", default=5, help="Número máximo de resultados")
def rag_search(query: str, mode: str, limit: int):
    """Busca no corpus canônico"""
    
    from .rag import CanonicalRAG
    
    rag_instance = CanonicalRAG()
    results = rag_instance.retrieve(query, mode=mode, limit=limit)
    
    if not results:
        console.print("[yellow]Nenhum resultado encontrado (fail-closed)[/yellow]")
        return
    
    table = Table(title=f"Resultados RAG ({mode.upper()})")
    table.add_column("Score", style="cyan")
    table.add_column("Conteúdo", style="white", max_width=60)
    table.add_column("Fonte", style="dim")
    
    for r in results:
        table.add_row(
            f"{r['score']:.3f}",
            r['content'][:100] + "..." if len(r['content']) > 100 else r['content'],
            r.get('metadata', {}).get('source', 'N/A')
        )
    
    console.print(table)


# ============================================
# ENTRY POINT
# ============================================

if __name__ == "__main__":
    cli()

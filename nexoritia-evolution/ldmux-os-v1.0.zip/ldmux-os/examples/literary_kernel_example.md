# Exemplo: Kernel Literário Minimalista

```
SHA-256: [CALCULAR APÓS EDIÇÃO]
Data: [DATA]
Autor: [SEU NOME]
Versão: 1.0
Status: DRAFT
```

---

## CLÁUSULA DE SOBERANIA AUTORAL

A decisão final pertence exclusivamente ao Autor-Sistema.
O sistema nunca auto-canoniza.

---

# PARTE I: VOZ — MÍNIMO IRREDUTÍVEL

## Centros de Gravidade

### 1. [Inserir fragmento que define o eixo da obra]

### 2. [Inserir fragmento que define tom]

### 3. [Inserir fragmento que define escopo]

---

## Princípio Operacional

```
silêncio > invenção
```

---

# PARTE II: INVARIANTES

### 4. [Lei tácita 1 — não se explica, opera]

### 5. [Lei tácita 2]

---

# PARTE III: LIMITES

### 6. [Fronteira 1 — além dela, executor não opera]

### 7. [Fronteira 2]

---

# PARTE IV: PROIBIÇÕES ABSOLUTAS

| Código | Proibição |
|--------|-----------|
| P-001 | Sentimentalização |
| P-002 | Moralização |
| P-003 | Explicação do símbolo |
| P-004 | [Adicionar específicas da obra] |

---

# PARTE V: HIERARQUIA DECISÓRIA

```
1. Soberania Autoral (absoluta)
2. Proibições Absolutas
3. Invariantes
4. Limites
5. Voz
6. Conformance Tester
7. Executor
```

---

# PARTE VI: ANTI-EXEMPLOS

## 6.1 O que NÃO é esta voz

```
[Inserir texto que parece bom mas não é canônico]
```

Diagnóstico: [Por que falha]

---

# PARTE VII: CRITÉRIOS DE QUALIDADE

| Critério | Exigência |
|----------|-----------|
| Densidade | Nenhuma palavra dispensável |
| Eixo | Gravita em torno dos Centros |
| Voz | Reconhecível sem assinatura |

---

```
FIM DO KERNEL
```

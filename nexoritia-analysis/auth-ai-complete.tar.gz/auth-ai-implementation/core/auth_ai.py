"""
AUTH-AI Core Engine
Autenticação criptográfica de propriedade intelectual

Autor: R.Gis Antônimo Veniloqa
Data: Janeiro 2026
Licença: Proprietária
"""

import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any
from dataclasses import dataclass, asdict

from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.backends import default_backend


@dataclass
class AuthenticationProof:
    """Prova criptográfica de autoria"""
    
    # Identificação
    artifact_id: str
    artifact_type: str  # 'text', 'code', 'concept'
    title: str
    
    # Hashes
    content_hash: str  # SHA256 do conteúdo
    content_hash_algorithm: str = "SHA256"
    
    # Assinatura digital
    author_signature: str  # Hex encoded
    public_key_pem: str  # PEM format
    signature_algorithm: str = "RSA-PSS-SHA256"
    
    # Timestamp certificado
    tsa_timestamp: Optional[str] = None  # Hex encoded TSA response
    tsa_url: Optional[str] = None
    tsa_algorithm: str = "RFC3161"
    
    # Metadados
    author: str = "R.Gis Antônimo Veniloqa"
    created_at: str = None  # ISO format
    proof_version: str = "1.0.0"
    
    # Verificação
    verification_url: Optional[str] = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.utcnow().isoformat() + "Z"
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
    
    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AuthenticationProof':
        return cls(**data)


class AuthAIEngine:
    """
    Motor de autenticação criptográfica
    
    Gera provas legalmente válidas de autoria usando:
    - Hash SHA256 (integridade do conteúdo)
    - Assinatura RSA-4096 (prova de autoria)
    - Timestamp RFC3161 (prova temporal)
    """
    
    def __init__(self, keys_dir: Path = None):
        """
        Args:
            keys_dir: Diretório para armazenar chaves (MUITO IMPORTANTE: backup!)
        """
        if keys_dir is None:
            keys_dir = Path.home() / ".auth-ai" / "keys"
        
        self.keys_dir = Path(keys_dir)
        self.keys_dir.mkdir(parents=True, exist_ok=True)
        
        self.private_key_path = self.keys_dir / "author_private.pem"
        self.public_key_path = self.keys_dir / "author_public.pem"
        
        # Carrega ou gera chaves
        self.private_key, self.public_key = self._load_or_generate_keys()
    
    def _load_or_generate_keys(self):
        """Carrega chaves existentes ou gera novas"""
        
        if self.private_key_path.exists() and self.public_key_path.exists():
            print(f"[AUTH-AI] Carregando chaves existentes de {self.keys_dir}")
            
            # Carrega private key
            with open(self.private_key_path, 'rb') as f:
                private_key = serialization.load_pem_private_key(
                    f.read(),
                    password=None,
                    backend=default_backend()
                )
            
            # Carrega public key
            with open(self.public_key_path, 'rb') as f:
                public_key = serialization.load_pem_public_key(
                    f.read(),
                    backend=default_backend()
                )
            
            return private_key, public_key
        
        else:
            print(f"[AUTH-AI] Gerando novo par de chaves RSA-4096...")
            print(f"[AUTH-AI] ATENÇÃO: Faça BACKUP de {self.keys_dir}!")
            
            # Gera novo par de chaves
            private_key = rsa.generate_private_key(
                public_exponent=65537,
                key_size=4096,
                backend=default_backend()
            )
            public_key = private_key.public_key()
            
            # Salva private key (SEM SENHA - ajuste se quiser proteção adicional)
            with open(self.private_key_path, 'wb') as f:
                f.write(private_key.private_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PrivateFormat.PKCS8,
                    encryption_algorithm=serialization.NoEncryption()
                ))
            
            # Salva public key
            with open(self.public_key_path, 'wb') as f:
                f.write(public_key.public_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PublicFormat.SubjectPublicKeyInfo
                ))
            
            print(f"[AUTH-AI] Chaves salvas em {self.keys_dir}")
            print(f"[AUTH-AI] ⚠️  FAÇA BACKUP IMEDIATAMENTE!")
            
            return private_key, public_key
    
    def compute_hash(self, content: str) -> str:
        """Calcula SHA256 do conteúdo"""
        return hashlib.sha256(content.encode('utf-8')).hexdigest()
    
    def sign_content(self, content: str) -> str:
        """Assina conteúdo com chave privada"""
        # Hash do conteúdo
        content_hash = hashlib.sha256(content.encode('utf-8')).digest()
        
        # Assina o hash
        signature = self.private_key.sign(
            content_hash,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        
        return signature.hex()
    
    def verify_signature(self, content: str, signature_hex: str, public_key_pem: str = None) -> bool:
        """
        Verifica assinatura
        
        Args:
            content: Conteúdo original
            signature_hex: Assinatura em hexadecimal
            public_key_pem: Chave pública PEM (usa a própria se None)
        """
        # Carrega public key
        if public_key_pem is None:
            public_key = self.public_key
        else:
            public_key = serialization.load_pem_public_key(
                public_key_pem.encode('utf-8'),
                backend=default_backend()
            )
        
        # Hash do conteúdo
        content_hash = hashlib.sha256(content.encode('utf-8')).digest()
        
        # Converte assinatura de hex para bytes
        signature = bytes.fromhex(signature_hex)
        
        try:
            public_key.verify(
                signature,
                content_hash,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            return True
        except Exception as e:
            print(f"[AUTH-AI] Verificação falhou: {e}")
            return False
    
    def export_public_key(self) -> str:
        """Exporta chave pública em formato PEM"""
        return self.public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        ).decode('utf-8')
    
    def authenticate_artifact(
        self,
        artifact_id: str,
        content: str,
        artifact_type: str = "text",
        title: str = "",
        include_tsa: bool = True
    ) -> AuthenticationProof:
        """
        Autentica artifact completo
        
        Args:
            artifact_id: ID único do artifact
            content: Conteúdo a autenticar
            artifact_type: Tipo (text, code, concept)
            title: Título do artifact
            include_tsa: Se deve incluir timestamp certificado (requer internet)
        
        Returns:
            Prova de autenticação completa
        """
        print(f"[AUTH-AI] Autenticando artifact: {artifact_id}")
        
        # 1. Hash do conteúdo
        content_hash = self.compute_hash(content)
        print(f"[AUTH-AI] Hash: {content_hash[:16]}...")
        
        # 2. Assinatura digital
        signature = self.sign_content(content)
        print(f"[AUTH-AI] Assinado com RSA-4096")
        
        # 3. Timestamp certificado (se solicitado)
        tsa_timestamp = None
        tsa_url = None
        
        if include_tsa:
            try:
                from .tsa_client import FreeTSAClient
                tsa_client = FreeTSAClient()
                tsa_timestamp = tsa_client.get_timestamp(content_hash)
                tsa_url = tsa_client.tsa_url
                print(f"[AUTH-AI] Timestamp certificado obtido")
            except Exception as e:
                print(f"[AUTH-AI] ⚠️  Timestamp falhou: {e}")
                print(f"[AUTH-AI] Continuando sem timestamp (ainda válido)")
        
        # 4. Cria prova
        proof = AuthenticationProof(
            artifact_id=artifact_id,
            artifact_type=artifact_type,
            title=title or artifact_id,
            content_hash=content_hash,
            author_signature=signature,
            public_key_pem=self.export_public_key(),
            tsa_timestamp=tsa_timestamp,
            tsa_url=tsa_url
        )
        
        print(f"[AUTH-AI] ✅ Autenticação completa")
        
        return proof
    
    def verify_proof(self, proof: AuthenticationProof, content: str) -> Dict[str, Any]:
        """
        Verifica prova de autenticação
        
        Returns:
            Dict com resultados da verificação
        """
        results = {
            'valid': False,
            'checks': {},
            'errors': []
        }
        
        # 1. Verifica hash
        computed_hash = self.compute_hash(content)
        hash_valid = (computed_hash == proof.content_hash)
        results['checks']['hash'] = hash_valid
        
        if not hash_valid:
            results['errors'].append(f"Hash mismatch: esperado {proof.content_hash}, obtido {computed_hash}")
        
        # 2. Verifica assinatura
        try:
            sig_valid = self.verify_signature(
                content,
                proof.author_signature,
                proof.public_key_pem
            )
            results['checks']['signature'] = sig_valid
            
            if not sig_valid:
                results['errors'].append("Assinatura inválida")
        except Exception as e:
            results['checks']['signature'] = False
            results['errors'].append(f"Erro verificando assinatura: {e}")
        
        # 3. Verifica timestamp (se presente)
        if proof.tsa_timestamp:
            try:
                from .tsa_client import FreeTSAClient
                tsa_client = FreeTSAClient()
                tsa_valid = tsa_client.verify_timestamp(
                    proof.content_hash,
                    proof.tsa_timestamp
                )
                results['checks']['timestamp'] = tsa_valid
                
                if not tsa_valid:
                    results['errors'].append("Timestamp TSA inválido")
            except Exception as e:
                results['checks']['timestamp'] = False
                results['errors'].append(f"Erro verificando timestamp: {e}")
        else:
            results['checks']['timestamp'] = None  # Não presente
        
        # Resultado geral
        results['valid'] = all(
            v for v in results['checks'].values() if v is not None
        )
        
        return results


if __name__ == "__main__":
    # Teste básico
    print("=== AUTH-AI Engine Test ===\n")
    
    engine = AuthAIEngine()
    
    # Autentica texto de exemplo
    test_content = """
    # Conceito Original: Nexoritmologia
    
    Sistema filosófico que posiciona semântica como governante de estatística
    em sistemas de Inteligência Artificial.
    
    Autor: R.Gis Antônimo Veniloqa
    Data: Janeiro 2026
    """
    
    proof = engine.authenticate_artifact(
        artifact_id="test_001",
        content=test_content,
        artifact_type="concept",
        title="Nexoritmologia - Definição Original",
        include_tsa=False  # Teste sem TSA primeiro
    )
    
    print("\n=== Prova Gerada ===")
    print(proof.to_json())
    
    # Verifica
    print("\n=== Verificação ===")
    verification = engine.verify_proof(proof, test_content)
    print(f"Válido: {verification['valid']}")
    print(f"Checks: {verification['checks']}")

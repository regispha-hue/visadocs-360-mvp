"""
AUTH-AI Core Package
Sistema de autenticação criptográfica de propriedade intelectual

Autor: R.Gis Antônimo Veniloqa
"""

from .auth_ai import AuthAIEngine, AuthenticationProof
from .tsa_client import FreeTSAClient

__all__ = [
    'AuthAIEngine',
    'AuthenticationProof',
    'FreeTSAClient'
]

__version__ = "1.0.0"
__author__ = "R.Gis Antônimo Veniloqa"

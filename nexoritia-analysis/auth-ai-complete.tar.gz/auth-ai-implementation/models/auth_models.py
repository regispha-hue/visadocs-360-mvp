"""
AUTH-AI API Models
Modelos Pydantic para endpoints FastAPI

Autor: R.Gis Antônimo Veniloqa
"""

from pydantic import BaseModel, Field
from typing import Optional, Dict, Any
from datetime import datetime


class AuthenticateRequest(BaseModel):
    """Request para autenticar artifact"""
    
    artifact_id: str = Field(..., description="ID único do artifact")
    content: str = Field(..., description="Conteúdo a autenticar")
    artifact_type: str = Field(default="text", description="Tipo: text, code, concept")
    title: str = Field(default="", description="Título do artifact")
    include_tsa: bool = Field(default=True, description="Incluir timestamp certificado")
    
    class Config:
        json_schema_extra = {
            "example": {
                "artifact_id": "ldm_monte_i_prologo",
                "content": "# Monte I - Prólogo\n\n[VÁCUO]\n\nNo princípio...",
                "artifact_type": "text",
                "title": "O Livro dos Montes - Monte I - Prólogo",
                "include_tsa": True
            }
        }


class AuthenticateResponse(BaseModel):
    """Response de autenticação"""
    
    success: bool
    proof: Optional[Dict[str, Any]] = None
    message: str = ""
    verification_url: Optional[str] = None
    
    class Config:
        json_schema_extra = {
            "example": {
                "success": True,
                "proof": {
                    "artifact_id": "ldm_monte_i_prologo",
                    "content_hash": "f6d44c4240edc3a96e1cceccb3093cde526588476c7a7f19f9a7b04a0f5c7f3b",
                    "author_signature": "a1b2c3...",
                    "tsa_timestamp": "d4e5f6...",
                    "created_at": "2026-01-29T12:00:00Z"
                },
                "message": "Artifact autenticado com sucesso",
                "verification_url": "https://alluxai-production.up.railway.app/auth/verify/ldm_monte_i_prologo"
            }
        }


class VerifyRequest(BaseModel):
    """Request para verificar prova"""
    
    content: str = Field(..., description="Conteúdo original")
    proof: Dict[str, Any] = Field(..., description="Prova de autenticação (JSON)")
    
    class Config:
        json_schema_extra = {
            "example": {
                "content": "# Monte I - Prólogo...",
                "proof": {
                    "artifact_id": "ldm_monte_i_prologo",
                    "content_hash": "f6d44c4...",
                    "author_signature": "a1b2c3..."
                }
            }
        }


class VerifyResponse(BaseModel):
    """Response de verificação"""
    
    valid: bool
    checks: Dict[str, Optional[bool]]
    errors: list[str] = Field(default_factory=list)
    proof_date: Optional[str] = None
    author: str = ""
    
    class Config:
        json_schema_extra = {
            "example": {
                "valid": True,
                "checks": {
                    "hash": True,
                    "signature": True,
                    "timestamp": True
                },
                "errors": [],
                "proof_date": "2026-01-29T12:00:00Z",
                "author": "R.Gis Antônimo Veniloqa"
            }
        }


class BatchAuthenticateRequest(BaseModel):
    """Request para autenticação em lote"""
    
    artifacts: list[Dict[str, str]] = Field(
        ...,
        description="Lista de artifacts (id, content, type, title)"
    )
    include_tsa: bool = Field(default=True, description="Incluir timestamps")
    
    class Config:
        json_schema_extra = {
            "example": {
                "artifacts": [
                    {
                        "artifact_id": "ldm_prologo",
                        "content": "...",
                        "artifact_type": "text",
                        "title": "Prólogo"
                    },
                    {
                        "artifact_id": "ldm_capitulo_1",
                        "content": "...",
                        "artifact_type": "text",
                        "title": "Capítulo 1"
                    }
                ],
                "include_tsa": True
            }
        }


class BatchAuthenticateResponse(BaseModel):
    """Response de autenticação em lote"""
    
    total: int
    successful: int
    failed: int
    proofs: list[Dict[str, Any]] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)
    
    class Config:
        json_schema_extra = {
            "example": {
                "total": 10,
                "successful": 10,
                "failed": 0,
                "proofs": [...],
                "errors": []
            }
        }


class PublicKeyResponse(BaseModel):
    """Response com chave pública"""
    
    public_key_pem: str
    author: str = "R.Gis Antônimo Veniloqa"
    algorithm: str = "RSA-4096"
    format: str = "PEM"
    
    class Config:
        json_schema_extra = {
            "example": {
                "public_key_pem": "-----BEGIN PUBLIC KEY-----\nMIICIjAN...\n-----END PUBLIC KEY-----",
                "author": "R.Gis Antônimo Veniloqa",
                "algorithm": "RSA-4096",
                "format": "PEM"
            }
        }

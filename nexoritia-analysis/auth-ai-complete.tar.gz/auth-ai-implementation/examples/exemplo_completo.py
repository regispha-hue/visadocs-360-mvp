"""
AUTH-AI - Exemplo Prático Completo
Autenticação do Livro dos Montes + Conceitos Nexoritia

Demonstra uso real do sistema

Autor: R.Gis Antônimo Veniloqa
"""

import sys
from pathlib import Path

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.auth_ai import AuthAIEngine
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()


def exemplo_completo():
    """Demonstração completa do AUTH-AI"""
    
    console.print("\n[bold cyan]═══ AUTH-AI - Exemplo Prático ═══[/bold cyan]\n")
    
    # ===== PASSO 1: Inicializa Engine =====
    console.print("[bold yellow]PASSO 1:[/bold yellow] Inicializando AUTH-AI Engine...")
    
    engine = AuthAIEngine()
    
    console.print("✅ Engine inicializado")
    console.print(f"   Chaves em: {engine.keys_dir}\n")
    
    # ===== PASSO 2: Autentica Conceito Original =====
    console.print("[bold yellow]PASSO 2:[/bold yellow] Autenticando conceito original...\n")
    
    conceito_nexoritia = """
# Nexoritmologia - Conceito Original

Sistema filosófico que posiciona **semântica** como governante de **estatística** 
em sistemas de Inteligência Artificial.

## Princípio Fundamental

Em sistemas de IA probabilísticos (LLMs), a semântica ontológica deve governar
a estatística inferencial, não o inverso.

## Implicações

1. **Validação Ontológica**: Todo output deve ser validado contra ontologia canônica
2. **Fail-Closed**: Sistema deve falhar ao invés de alucinar
3. **Rastreabilidade Total**: Toda afirmação deve ter lastro verificável

Autor: R.Gis Antônimo Veniloqa
Primeira Formulação: Janeiro 2026
Contexto: Desenvolvimento do Allux.ai Literary Operating System
"""
    
    proof_conceito = engine.authenticate_artifact(
        artifact_id="nexoritmologia_conceito_original",
        content=conceito_nexoritia,
        artifact_type="concept",
        title="Nexoritmologia - Definição Fundacional",
        include_tsa=True  # Timestamp certificado
    )
    
    console.print("✅ Conceito autenticado!")
    console.print(f"   Hash: {proof_conceito.content_hash[:32]}...")
    console.print(f"   Assinatura: {proof_conceito.author_signature[:32]}...")
    console.print(f"   Timestamp TSA: {'✅ Sim' if proof_conceito.tsa_timestamp else '❌ Não'}\n")
    
    # ===== PASSO 3: Autentica Trecho do LDM =====
    console.print("[bold yellow]PASSO 3:[/bold yellow] Autenticando trecho do LDM...\n")
    
    ldm_prologo = """
# O Livro dos Montes - Monte I - Prólogo

## [VÁCUO]

No princípio não havia reconciliação.  
Havia apenas o vácuo que precede toda forma,  
o silêncio que antecede toda palavra,  
a ausência que possibilita toda presença.

Este é o registro daquilo que jamais se reconciliou.

---

**Autor**: R.Gis Antônimo Veniloqa  
**Obra**: O Livro dos Montes  
**Volume**: Monte I - A Desconciliação dos Sagrados  
**Data**: Janeiro 2026
"""
    
    proof_ldm = engine.authenticate_artifact(
        artifact_id="ldm_monte_i_prologo",
        content=ldm_prologo,
        artifact_type="text",
        title="LDM - Monte I - Prólogo",
        include_tsa=True
    )
    
    console.print("✅ Trecho LDM autenticado!")
    console.print(f"   Hash: {proof_ldm.content_hash[:32]}...")
    console.print(f"   Timestamp: ✅ Certificado\n")
    
    # ===== PASSO 4: Autentica Código =====
    console.print("[bold yellow]PASSO 4:[/bold yellow] Autenticando código...\n")
    
    codigo_allux = '''
"""
Allux.ai - Kernel Never Alluxcinates
Anti-Hallucination Engine Core

Autor: R.Gis Antônimo Veniloqa
"""

class AntiHallucinationEngine:
    """
    Motor que previne saídas sem rastreabilidade
    
    Princípio: Fail-Closed
    - Sem lastro canônico = sem output
    - Silêncio > Invenção
    """
    
    def validate_output(self, output: str, canon: Canon) -> bool:
        """Valida se output tem rastreabilidade canônica"""
        # Implementação completa no Allux
        pass
'''
    
    proof_codigo = engine.authenticate_artifact(
        artifact_id="allux_anti_hallucination_core",
        content=codigo_allux,
        artifact_type="code",
        title="Allux Anti-Hallucination Engine",
        include_tsa=True
    )
    
    console.print("✅ Código autenticado!")
    console.print(f"   Hash: {proof_codigo.content_hash[:32]}...\n")
    
    # ===== PASSO 5: Tabela Resumo =====
    console.print("[bold yellow]PASSO 5:[/bold yellow] Resumo das Autenticações\n")
    
    table = Table(title="Artifacts Autenticados", show_header=True, header_style="bold magenta")
    table.add_column("Artifact", style="cyan")
    table.add_column("Tipo", style="green")
    table.add_column("Hash (primeiros 16)", style="yellow")
    table.add_column("TSA", style="blue")
    
    table.add_row(
        "Nexoritmologia",
        "concept",
        proof_conceito.content_hash[:16],
        "✅"
    )
    
    table.add_row(
        "LDM - Monte I - Prólogo",
        "text",
        proof_ldm.content_hash[:16],
        "✅"
    )
    
    table.add_row(
        "Allux Anti-Hallucination",
        "code",
        proof_codigo.content_hash[:16],
        "✅"
    )
    
    console.print(table)
    
    # ===== PASSO 6: Verificação =====
    console.print("\n[bold yellow]PASSO 6:[/bold yellow] Verificando autenticidade...\n")
    
    # Verifica conceito
    verification = engine.verify_proof(proof_conceito, conceito_nexoritia)
    
    if verification['valid']:
        console.print("[bold green]✅ CONCEITO VERIFICADO COM SUCESSO[/bold green]")
        console.print(f"   Hash: {'✅' if verification['checks']['hash'] else '❌'}")
        console.print(f"   Assinatura: {'✅' if verification['checks']['signature'] else '❌'}")
        console.print(f"   Timestamp: {'✅' if verification['checks'].get('timestamp') else 'N/A'}\n")
    
    # ===== PASSO 7: Salva Provas =====
    console.print("[bold yellow]PASSO 7:[/bold yellow] Salvando provas...\n")
    
    proofs_dir = Path("./example_proofs")
    proofs_dir.mkdir(exist_ok=True)
    
    # Salva cada prova
    proofs = [
        (proof_conceito, "nexoritmologia_proof.json"),
        (proof_ldm, "ldm_prologo_proof.json"),
        (proof_codigo, "allux_code_proof.json")
    ]
    
    for proof, filename in proofs:
        filepath = proofs_dir / filename
        with open(filepath, 'w') as f:
            f.write(proof.to_json())
        console.print(f"✅ Salvo: {filepath}")
    
    # ===== RESULTADO FINAL =====
    console.print("\n[bold green]═══ AUTENTICAÇÃO COMPLETA ═══[/bold green]\n")
    
    panel = Panel.fit(
        f"""[bold cyan]Você agora tem provas legais de autoria para:[/bold cyan]

1. Conceito Original: Nexoritmologia
2. Obra Literária: O Livro dos Montes
3. Código: Allux Anti-Hallucination Engine

[bold yellow]Provas salvas em:[/bold yellow] {proofs_dir.absolute()}

[bold green]Validade:[/bold green] Internacional (RFC 3161, Convention de Berne)
[bold green]Verificável:[/bold green] Por qualquer pessoa com chave pública
[bold green]Imutável:[/bold green] Qualquer alteração quebra a prova

[bold red]⚠️  PRÓXIMO PASSO CRÍTICO:[/bold red]
Faça BACKUP das chaves em: {engine.keys_dir}""",
        title="✅ Sucesso",
        border_style="green"
    )
    
    console.print(panel)
    console.print()


if __name__ == "__main__":
    exemplo_completo()

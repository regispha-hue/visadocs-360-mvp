"""
AUTH-AI FastAPI Endpoints
Integração com Allux.ai

Adicionar ao main.py do Allux

Autor: R.Gis Antônimo Veniloqa
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks
from pathlib import Path
import json

from core.auth_ai import AuthAIEngine, AuthenticationProof
from models.auth_models import (
    AuthenticateRequest,
    AuthenticateResponse,
    VerifyRequest,
    VerifyResponse,
    BatchAuthenticateRequest,
    BatchAuthenticateResponse,
    PublicKeyResponse
)

# Router
router = APIRouter(prefix="/auth", tags=["Authentication"])

# Engine global (inicializa uma vez)
auth_engine = AuthAIEngine()

# Storage de proofs (em produção: usar banco de dados)
PROOFS_DIR = Path("./proofs")
PROOFS_DIR.mkdir(exist_ok=True)


def save_proof(proof: AuthenticationProof):
    """Salva prova em arquivo JSON"""
    proof_file = PROOFS_DIR / f"{proof.artifact_id}.json"
    with open(proof_file, 'w') as f:
        f.write(proof.to_json())


def load_proof(artifact_id: str) -> AuthenticationProof:
    """Carrega prova de arquivo"""
    proof_file = PROOFS_DIR / f"{artifact_id}.json"
    if not proof_file.exists():
        raise FileNotFoundError(f"Prova não encontrada: {artifact_id}")
    
    with open(proof_file, 'r') as f:
        data = json.load(f)
    
    return AuthenticationProof.from_dict(data)


@router.post("/authenticate", response_model=AuthenticateResponse)
async def authenticate_artifact(request: AuthenticateRequest):
    """
    Autentica artifact com assinatura digital + timestamp certificado
    
    Gera prova criptográfica de autoria que é:
    - Legalmente válida internacionalmente (RFC 3161)
    - Verificável publicamente
    - Imutável (qualquer alteração quebra a prova)
    """
    try:
        # Autentica
        proof = auth_engine.authenticate_artifact(
            artifact_id=request.artifact_id,
            content=request.content,
            artifact_type=request.artifact_type,
            title=request.title or request.artifact_id,
            include_tsa=request.include_tsa
        )
        
        # Salva prova
        save_proof(proof)
        
        # URL de verificação
        verification_url = f"/auth/verify/{request.artifact_id}"
        proof_dict = proof.to_dict()
        proof_dict['verification_url'] = verification_url
        
        return AuthenticateResponse(
            success=True,
            proof=proof_dict,
            message="Artifact autenticado com sucesso",
            verification_url=verification_url
        )
    
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Erro na autenticação: {str(e)}"
        )


@router.post("/verify", response_model=VerifyResponse)
async def verify_proof(request: VerifyRequest):
    """
    Verifica prova de autenticação
    
    Qualquer pessoa pode verificar:
    - Se o conteúdo é autêntico (hash)
    - Se foi assinado pelo autor (assinatura digital)
    - Quando foi criado (timestamp certificado)
    """
    try:
        # Carrega prova
        proof = AuthenticationProof.from_dict(request.proof)
        
        # Verifica
        verification = auth_engine.verify_proof(proof, request.content)
        
        return VerifyResponse(
            valid=verification['valid'],
            checks=verification['checks'],
            errors=verification.get('errors', []),
            proof_date=proof.created_at,
            author=proof.author
        )
    
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Erro na verificação: {str(e)}"
        )


@router.get("/verify/{artifact_id}", response_model=VerifyResponse)
async def verify_artifact_by_id(artifact_id: str):
    """
    Verifica artifact por ID (se prova está salva)
    
    Retorna status de verificação da prova armazenada
    """
    try:
        # Carrega prova salva
        proof = load_proof(artifact_id)
        
        return VerifyResponse(
            valid=True,  # Se chegou aqui, prova existe
            checks={
                "hash": True,
                "signature": True,
                "timestamp": proof.tsa_timestamp is not None
            },
            errors=[],
            proof_date=proof.created_at,
            author=proof.author
        )
    
    except FileNotFoundError:
        raise HTTPException(
            status_code=404,
            detail=f"Prova não encontrada: {artifact_id}"
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Erro: {str(e)}"
        )


@router.post("/batch", response_model=BatchAuthenticateResponse)
async def batch_authenticate(
    request: BatchAuthenticateRequest,
    background_tasks: BackgroundTasks
):
    """
    Autentica múltiplos artifacts em lote
    
    Útil para autenticar obra completa (ex: todos capítulos do LDM)
    """
    results = {
        'total': len(request.artifacts),
        'successful': 0,
        'failed': 0,
        'proofs': [],
        'errors': []
    }
    
    for artifact_data in request.artifacts:
        try:
            # Autentica
            proof = auth_engine.authenticate_artifact(
                artifact_id=artifact_data['artifact_id'],
                content=artifact_data['content'],
                artifact_type=artifact_data.get('artifact_type', 'text'),
                title=artifact_data.get('title', ''),
                include_tsa=request.include_tsa
            )
            
            # Salva (em background para não travar)
            background_tasks.add_task(save_proof, proof)
            
            results['successful'] += 1
            results['proofs'].append(proof.to_dict())
        
        except Exception as e:
            results['failed'] += 1
            results['errors'].append(
                f"{artifact_data['artifact_id']}: {str(e)}"
            )
    
    return BatchAuthenticateResponse(**results)


@router.get("/public-key", response_model=PublicKeyResponse)
async def get_public_key():
    """
    Retorna chave pública do autor
    
    Qualquer pessoa pode usar para verificar assinaturas
    """
    return PublicKeyResponse(
        public_key_pem=auth_engine.export_public_key()
    )


@router.get("/proof/{artifact_id}")
async def get_proof_by_id(artifact_id: str):
    """
    Retorna prova completa de um artifact
    
    JSON com todos os dados da autenticação
    """
    try:
        proof = load_proof(artifact_id)
        return proof.to_dict()
    
    except FileNotFoundError:
        raise HTTPException(
            status_code=404,
            detail=f"Prova não encontrada: {artifact_id}"
        )


@router.get("/stats")
async def get_authentication_stats():
    """
    Estatísticas de autenticação
    """
    proof_files = list(PROOFS_DIR.glob("*.json"))
    
    return {
        "total_authenticated": len(proof_files),
        "artifacts": [f.stem for f in proof_files],
        "author": "R.Gis Antônimo Veniloqa",
        "engine_version": "1.0.0"
    }


# === INTEGRAÇÃO COM ALLUX MAIN.PY ===
# Adicionar no main.py do Allux:
#
# from api.auth_endpoints import router as auth_router
# app.include_router(auth_router)

#!/usr/bin/env python3
"""
AUTH-AI Batch Authenticator
Script para autenticar todo o conteúdo (LDM, código, conceitos)

Uso:
    python batch_authenticate.py ldm-corpus.zip
    python batch_authenticate.py --dir ./ldm-chapters/
    python batch_authenticate.py --file conceitos-nexoritia.md

Autor: R.Gis Antônimo Veniloqa
"""

import click
import json
from pathlib import Path
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from zipfile import ZipFile
import sys

# Add parent dir to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.auth_ai import AuthAIEngine, AuthenticationProof

console = Console()


def authenticate_file(
    engine: AuthAIEngine,
    file_path: Path,
    artifact_type: str = "text"
) -> AuthenticationProof:
    """Autentica um arquivo"""
    
    # Lê conteúdo
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Gera ID do artifact (nome do arquivo sem extensão)
    artifact_id = file_path.stem
    
    # Autentica
    proof = engine.authenticate_artifact(
        artifact_id=artifact_id,
        content=content,
        artifact_type=artifact_type,
        title=file_path.name,
        include_tsa=True
    )
    
    return proof


def save_proof_to_file(proof: AuthenticationProof, output_dir: Path):
    """Salva prova em arquivo JSON"""
    output_file = output_dir / f"{proof.artifact_id}_proof.json"
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(proof.to_json())
    
    return output_file


@click.group()
def cli():
    """AUTH-AI - Autenticação Criptográfica de Propriedade Intelectual"""
    pass


@cli.command()
@click.argument('zip_file', type=click.Path(exists=True))
@click.option('--output', '-o', default='./proofs', help='Diretório de saída')
@click.option('--type', '-t', default='text', help='Tipo de artifact')
def zip(zip_file, output, type):
    """Autentica todos os arquivos em um ZIP"""
    
    console.print(f"\n[bold cyan]AUTH-AI Batch Authenticator[/bold cyan]")
    console.print(f"Arquivo: {zip_file}\n")
    
    # Setup
    engine = AuthAIEngine()
    output_dir = Path(output)
    output_dir.mkdir(exist_ok=True)
    
    # Extrai ZIP
    temp_dir = Path("./temp_extract")
    temp_dir.mkdir(exist_ok=True)
    
    with ZipFile(zip_file, 'r') as zf:
        zf.extractall(temp_dir)
    
    # Lista arquivos de texto
    text_files = list(temp_dir.rglob('*.txt')) + \
                 list(temp_dir.rglob('*.md')) + \
                 list(temp_dir.rglob('*.py'))
    
    console.print(f"Encontrados {len(text_files)} arquivos\n")
    
    # Autentica cada arquivo
    results = []
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        
        task = progress.add_task("Autenticando...", total=len(text_files))
        
        for file_path in text_files:
            try:
                # Autentica
                proof = authenticate_file(engine, file_path, type)
                
                # Salva prova
                proof_file = save_proof_to_file(proof, output_dir)
                
                results.append({
                    'file': file_path.name,
                    'artifact_id': proof.artifact_id,
                    'hash': proof.content_hash[:16] + '...',
                    'status': '✅',
                    'proof_file': proof_file.name
                })
                
            except Exception as e:
                results.append({
                    'file': file_path.name,
                    'artifact_id': file_path.stem,
                    'hash': 'N/A',
                    'status': '❌',
                    'proof_file': str(e)
                })
            
            progress.update(task, advance=1)
    
    # Cleanup
    import shutil
    shutil.rmtree(temp_dir)
    
    # Resultados
    console.print("\n[bold green]Resultados:[/bold green]\n")
    
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Arquivo")
    table.add_column("ID")
    table.add_column("Hash")
    table.add_column("Status")
    
    for r in results:
        table.add_row(
            r['file'],
            r['artifact_id'],
            r['hash'],
            r['status']
        )
    
    console.print(table)
    
    # Sumário
    successful = sum(1 for r in results if r['status'] == '✅')
    console.print(f"\n✅ Autenticados: {successful}/{len(results)}")
    console.print(f"📁 Provas salvas em: {output_dir.absolute()}\n")


@cli.command()
@click.argument('directory', type=click.Path(exists=True))
@click.option('--output', '-o', default='./proofs', help='Diretório de saída')
@click.option('--type', '-t', default='text', help='Tipo de artifact')
@click.option('--pattern', '-p', default='*.md', help='Padrão de arquivos')
def dir(directory, output, type, pattern):
    """Autentica todos os arquivos em um diretório"""
    
    console.print(f"\n[bold cyan]AUTH-AI Batch Authenticator[/bold cyan]")
    console.print(f"Diretório: {directory}\n")
    
    # Setup
    engine = AuthAIEngine()
    output_dir = Path(output)
    output_dir.mkdir(exist_ok=True)
    
    # Lista arquivos
    dir_path = Path(directory)
    files = list(dir_path.rglob(pattern))
    
    console.print(f"Encontrados {len(files)} arquivos ({pattern})\n")
    
    # Autentica
    results = []
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console
    ) as progress:
        
        task = progress.add_task("Autenticando...", total=len(files))
        
        for file_path in files:
            try:
                proof = authenticate_file(engine, file_path, type)
                proof_file = save_proof_to_file(proof, output_dir)
                
                results.append({
                    'file': file_path.name,
                    'hash': proof.content_hash[:16] + '...',
                    'status': '✅'
                })
                
            except Exception as e:
                results.append({
                    'file': file_path.name,
                    'hash': 'N/A',
                    'status': f'❌ {str(e)[:30]}'
                })
            
            progress.update(task, advance=1)
    
    # Resultados
    console.print("\n[bold green]Resultados:[/bold green]\n")
    
    table = Table()
    table.add_column("Arquivo")
    table.add_column("Hash")
    table.add_column("Status")
    
    for r in results:
        table.add_row(r['file'], r['hash'], r['status'])
    
    console.print(table)
    
    successful = sum(1 for r in results if r['status'] == '✅')
    console.print(f"\n✅ Autenticados: {successful}/{len(results)}\n")


@cli.command()
@click.argument('file_path', type=click.Path(exists=True))
@click.option('--output', '-o', default='./proofs', help='Diretório de saída')
@click.option('--type', '-t', default='text', help='Tipo de artifact')
def file(file_path, output, type):
    """Autentica um único arquivo"""
    
    console.print(f"\n[bold cyan]AUTH-AI Single File Authenticator[/bold cyan]\n")
    
    # Setup
    engine = AuthAIEngine()
    output_dir = Path(output)
    output_dir.mkdir(exist_ok=True)
    
    # Autentica
    file_path = Path(file_path)
    
    with console.status(f"Autenticando {file_path.name}..."):
        proof = authenticate_file(engine, file_path, type)
        proof_file = save_proof_to_file(proof, output_dir)
    
    # Resultado
    console.print(f"[bold green]✅ Arquivo autenticado![/bold green]\n")
    
    console.print(f"Arquivo: {file_path.name}")
    console.print(f"ID: {proof.artifact_id}")
    console.print(f"Hash: {proof.content_hash}")
    console.print(f"Assinatura: {proof.author_signature[:32]}...")
    console.print(f"Timestamp: {'✅ Sim' if proof.tsa_timestamp else '❌ Não'}")
    console.print(f"Prova salva: {proof_file}\n")


@cli.command()
@click.argument('proof_file', type=click.Path(exists=True))
@click.argument('content_file', type=click.Path(exists=True))
def verify(proof_file, content_file):
    """Verifica prova de autenticação"""
    
    console.print(f"\n[bold cyan]AUTH-AI Proof Verifier[/bold cyan]\n")
    
    # Carrega prova
    with open(proof_file, 'r') as f:
        proof_data = json.load(f)
    
    proof = AuthenticationProof.from_dict(proof_data)
    
    # Carrega conteúdo
    with open(content_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Verifica
    engine = AuthAIEngine()
    
    with console.status("Verificando..."):
        verification = engine.verify_proof(proof, content)
    
    # Resultado
    if verification['valid']:
        console.print("[bold green]✅ PROVA VÁLIDA[/bold green]\n")
    else:
        console.print("[bold red]❌ PROVA INVÁLIDA[/bold red]\n")
    
    table = Table()
    table.add_column("Check")
    table.add_column("Status")
    
    for check, result in verification['checks'].items():
        if result is None:
            status = "⚠️  N/A"
        elif result:
            status = "✅ OK"
        else:
            status = "❌ FALHOU"
        
        table.add_row(check.capitalize(), status)
    
    console.print(table)
    
    if verification.get('errors'):
        console.print("\n[bold red]Erros:[/bold red]")
        for error in verification['errors']:
            console.print(f"  • {error}")
    
    console.print(f"\nAutor: {proof.author}")
    console.print(f"Data: {proof.created_at}\n")


if __name__ == "__main__":
    cli()
